<html>
	<head>
		<style>
		<?php include 'main.css'; ?>
		</style>
	</head>
	<body>
		<div id="logo">
			<img src="iona.jpg" alt='Official logo' width='180px' height='60px'>
		</div>
		<br /><br />
	</body>
</html>
<?php
	include("dbConnection.php");
	
	session_start();
	
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);
	
	if (isset($_SESSION['UserID']))
	{
		$ID = $_SESSION['UserID'];
	}

	if (!empty($_POST["stringIn"]))
	{
		$StringIn = $_POST['stringIn'];		
	
		$sql = "UPDATE `InsecureUsers` SET `StringInputInsecure` = '".$StringIn."' WHERE `InsecureID` = '".$ID."' ;";

		if ($db->query($sql) == TRUE)
		{
			echo "<script type='text/javascript'>
					alert('String saved successfully.')
					</script>";
					
			echo "<script type='text/javascript'>
			window.location.href = './InsecureStringDisplay.php';
			</script>";
			
		} else {
			echo "<script type='text/javascript'>
					alert('Could not save this string.')
					</script>";
					
			echo "<script type='text/javascript'>
			window.location.href = './StringInsertInsecure.html';
			</script>";
		}
	} else {
		echo "<script type='text/javascript'>
				alert('Please enter a string.')
				</script>";
				
		echo "<script type='text/javascript'>
			window.location.href = './StringInsertInsecure.html';
			</script>";
	}

	$db->close();
?>

