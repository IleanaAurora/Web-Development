<html>
	<head>
		<style>
		<?php include 'main.css'; ?>
		</style>
	</head>
	<body>
		<div id="logo">
			<img src="iona.jpg" alt='Official logo' width='180px' height='60px'>
		</div>
		<br /><br />
<?php
	
	include ("dbConnection.php");
	
	session_start();
	
	if (isset($_SESSION['UserID']))
	{
		$userID = $_SESSION['UserID'];
	}
	
	$stringResult = $db->query("SELECT `StringInputInsecure` FROM `InsecureUsers` WHERE `InsecureID` = '".$userID."'");
	
	if($stringResult->num_rows > 0)
	{
		$str = $stringResult->fetch_assoc();
		
		//echo "Your saved string: ";
		//echo $str["StringInputInsecure"];
		echo "<h2>Your saved string is: ".$str["StringInputInsecure"]."</h2>";
		
	} else {
		echo "<script type='text/javascript'>
		alert('There is no string to display.')
		</script>";
	}
	
?>
		<br /><br />
		<button id='' class='float-center submit-button'><a href='StringInsertInsecure.html' class='btn btn-warning'>Back</a></button>
	</body>
</html>