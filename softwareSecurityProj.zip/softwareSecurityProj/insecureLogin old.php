<?php
	include("dbConnection.php");
	
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);
	
	session_start();
		
	if (!empty($_GET["username"]) && !empty($_GET["password"]))
	{
		$username = $_GET['username'];
		$password = $_GET['password'];
		
		$result = $db->query("SELECT * FROM SecureUsers WHERE username='".$username."' AND password='".$password."'");
		if ($result->num_rows)
		{
			$row = $result->fetch_assoc();			
			$_SESSION['UserID'] = $row['SecureID'];
		}
		else
		{
			echo "<script language='javascript'>
			alert('LOGIN FAILURE: Invalid username and password.')
			</script>";
		}
				
			
		$db->close();
	}
	else
	{
		if (isset($_GET['username']))
		{
			if ((isset($_GET['username'])!="") && (isset($_GET['password'])==""))
			{
				echo "<script language='javascript'>
				alert('LOGIN FAILURE: You must provide a valid password.')
				</script>";
			}
			else
			{
				echo "<script language='javascript'>
				alert('LOGIN FAILURE: Please enter a valid username and password.')
				</script>";
			}
		}
	}
	if (isset($_SESSION['UserID']))
	{
		echo "<script type='text/javascript'>
			alert('LOGIN SUCCESSFUL.')
			</script>";
	}
	
	// Unset all of the session variables
	$_SESSION = array();
	 
	// Destroy the session.
	session_destroy();
	
?>

<!DOCTYPE html>
<html>
    
<head>
	<title>Login</title>
</head>
<body>
	<form method='GET' action='index.php'>
	<h1><b><label class="header-text" for="username">INSECURE USER LOGIN</label></b></h1>
		<div class="input-group mb-3">
			<div class="input-group-append">
				<span class="input-group-text"><i class="fas fa-user"></i></span>
			</div>
			<input type="text" name="username" class="form-control input_user" value="" placeholder="username">
		</div>
		<div class="input-group mb-2">
			<div class="input-group-append">
				<span class="input-group-text"><i class="fas fa-key"></i></span>
			</div>
			<input type="password" name="password" class="form-control input_pass" value="" placeholder="password">
		</div>
			<div class="d-flex justify-content-center mt-3 login_container">
	<button type="submit" name="button" class="btn login_btn">Login</button>
   </div>
	</form>
</body>
</html>
</html>