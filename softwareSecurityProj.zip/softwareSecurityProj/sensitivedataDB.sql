create database sensitivedata;
Use sensitivedata;

CREATE TABLE SecureUsers (
SecureID INT NOT NULL auto_increment,
Username	VARCHAR(30) NOT NULL,
Password	VARCHAR(150) NOT NULL,
Name VARCHAR(80) NOT NULL,
Phone	VARCHAR(20) NOT NULL,
Email	VARCHAR(40) NOT NULL,
SSN	VARCHAR(11) NOT NULL,
StringInputSecure VARCHAR(150),
CONSTRAINT SecureID PRIMARY KEY (SecureID));

CREATE TABLE InsecureUsers (
InsecureID INT NOT NULL auto_increment,
Username	VARCHAR(30) NOT NULL,
Password	VARCHAR(50) NOT NULL,
Name VARCHAR(80) NOT NULL,
Phone	VARCHAR(20) NOT NULL,
Email	VARCHAR(40) NOT NULL,
SSN	VARCHAR(11) NOT NULL,
StringInputInsecure VARCHAR(50),
CONSTRAINT InsecureID PRIMARY KEY (InsecureID));

CREATE TABLE EcryptionInfo (
EncryptionID INT NOT NULL auto_increment,
SecureID	INT NOT NULL,
eKey	VARCHAR(50) NOT NULL,
vector VARCHAR(50) NOT NULL,
vectorLength	INT NOT NULL,
CONSTRAINT EncryptionID PRIMARY KEY (EncryptionID),
CONSTRAINT EcryptionInfo_SecureID_fk FOREIGN KEY (SecureID) REFERENCES SecureUsers (SecureID));

INSERT INTO SecureUsers (Username,Password,Name,Phone,Email,SSN) VALUES ("admin","d033e22ae348aeb5660fc2140aec35850c4da997","Clark Kent", "(914) 714-6225","ckent85@outlook.com","158-96-2478");
INSERT INTO SecureUsers (Username,Password,Name,Phone,Email,SSN) VALUES ("user1","b3daa77b4c04a9551b8781d03191fe098f325e67","Bruce Wayne", "(815) 971-2013","imbatman@yahoo.com","236-14-5546");
INSERT INTO SecureUsers (Username,Password,Name,Phone,Email,SSN) VALUES ("user2","a1881c06eec96db9901c7bbfe41c42a3f08e9cb4","Peter Parker", "(852) 589-5962","pparker@gmail.com","158-96-2478");
INSERT INTO SecureUsers (Username,Password,Name,Phone,Email,SSN) VALUES ("user3","0b7f849446d3383546d15a480966084442cd2193","Tony Stark", "(586) 586-3641","iamironman@aol.com","236-14-5546");

INSERT INTO InsecureUsers (Username,Password,Name,Phone,Email,SSN) VALUES ("admin","admin","Diana Prince", "(817) 256-9881","princess@outlook.com","526-61-7814");
INSERT INTO InsecureUsers (Username,Password,Name,Phone,Email,SSN) VALUES ("user1","user1","Steve Rogers", "(465) 746-6225","supersoldier@yahoo.com","528-18-1876");
INSERT INTO InsecureUsers (Username,Password,Name,Phone,Email,SSN) VALUES ("user2","user2","Natasha Romanoff", "(980) 124-7320","nromanoff@gmail.com","551-81-1584");
INSERT INTO InsecureUsers (Username,Password,Name,Phone,Email,SSN) VALUES ("user3","user3","Bruce Banner", "(614) 323-7665","hulksmash@aol.com","418-80-8427");