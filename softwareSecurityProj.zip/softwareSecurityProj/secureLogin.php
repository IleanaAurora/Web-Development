<?php
	include("dbConnection.php");
	
	session_start();
			
	if (!empty($_POST["username"]) && !empty($_POST["password"]))
	{
		$username = $_POST['username'];
		$password = $_POST['password'];
		
		if (!preg_match('/^[a-zA-Z0-9_]{5,20}$/', $username))
			echo "<script type='text/javascript'>
				alert('You have entered an invalid username.')
				</script>";
		if (!preg_match('/^[a-zA-Z0-9_]{5,20}$/', $password))
			echo "<script type='text/javascript'>
				alert('You have entered an invalid password.')
				</script>";
		else
		{
			$username = filter_var($username, FILTER_SANITIZE_STRING);
			$password = filter_var($password, FILTER_SANITIZE_STRING);

			$db->set_charset("utf8");
			$username = $db->real_escape_string($username);
			$password = $db->real_escape_string($password);
			$password = sha1($password);
							
			if($prep = $db->prepare("SELECT SecureID FROM SecureUsers WHERE Username=? AND Password=?")){
				$prep->bind_param("ss", $username, $password);
				$prep->execute();
				$prep->store_result();
				$prep->bind_result($SecureID);
				$prep->fetch();
				if ($prep->num_rows === 1)
					$_SESSION['UserID'] = $SecureID;
				else
					echo "<script type='text/javascript'>
						alert('Wrong username and password.')
						</script>";
				$prep->close();
			}
		}	
		$db->close();
	}
	else
	{
		if (isset($_POST['username']))
		{
			if ((isset($_POST['username'])!="") && (isset($_POST['password'])==""))
			{
				echo "<script language='javascript'>
				alert('LOGIN FAILURE: You must provide a valid password.')
				</script>";
			}
			else
			{
				echo "<script language='javascript'>
				alert('LOGIN FAILURE: Please enter a valid username and password.')
				</script>";
			}
		}
	}
	if (isset($_SESSION['UserID']))
	{
		echo "<script type='text/javascript'>
			alert('LOGIN SUCCESSFUL.')
			</script>";
			
		echo "<script type='text/javascript'>
			window.location.href = './StringInsertSecure.html';
			</script>";
	}
	
	// Unset all of the session variables
	//$_SESSION = array();
	 
	// Destroy the session.
	//session_destroy();
	
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Login</title>
		<style>
		<?php include 'main.css'; ?>
		</style>
	</head>
	<body>
		<div id="logo">
			<img src="iona.jpg" alt='Official logo' width='180px' height='60px'>
		</div>
		<br /><br />
		<form action= "secureLogin.php" method="post">
		<h1><b><label for="username">SECURE USER LOGIN</label></b></h1>
			<p>
				<label for="username"><b>Username:</b></label>
				<input type="text" name="username" value="">​<br>
				<label for="password"><b>Password:</b></label>
				<input type="password" name="password" value="">​<br>
			</p>
			
			<p>
				<input type="submit" name="Submit" value="Login">
			</p>
		</form>
		<button id="" class="float-center submit-button" ><a href="index.php" class="btn btn-warning">Back to the Welcome Page</a></button>
	</body>
</html>