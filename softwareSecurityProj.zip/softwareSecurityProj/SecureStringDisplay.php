<html>
	<head>
		<style>
		<?php include 'main.css'; ?>
		</style>
	</head>
	<body>
		<div id="logo">
			<img src="iona.jpg" alt='Official logo' width='180px' height='60px'>
		</div>
		<br /><br />
<?php
	
	include ("dbConnection.php");
	
	session_start();
	
	if (isset($_SESSION['UserID']))
	{
		$userID = $_SESSION['UserID'];
	}
	
	$stringResult = $db->query("SELECT `StringInputSecure` FROM `SecureUsers` WHERE `SecureID` = '".$userID."'");
	
	if($stringResult->num_rows > 0)
	{
		while($row = $stringResult->fetch_assoc()) {
			$ciphertext  = $row["StringInputSecure"];
		}
		
		$eInfo = $db->query("SELECT SecureID, eKey, vector, vectorLength, MAX(EncryptionID) EncryptionID FROM EncryptionInfo WHERE SecureID='".$userID."' GROUP BY SecureID");
		
		if($eInfo->num_rows > 0)
		{
			$infoArray = $eInfo->fetch_assoc();
			
			$key = $infoArray["eKey"];
			
			$c = base64_decode($ciphertext);
			echo "<h2>The encrypted string is: ".$ciphertext."</h2>";
			//echo "The encrypted string is: ".$ciphertext;
			//echo "<br />";
			$ivlen = openssl_cipher_iv_length($cipher="AES-128-CBC");
			$iv = substr($c, 0, $ivlen);
			$hmac = substr($c, $ivlen, $sha2len=32);
			$ciphertext_raw = substr($c, $ivlen+$sha2len);
			$original_plaintext = openssl_decrypt($ciphertext_raw, $cipher, $key, $options=OPENSSL_RAW_DATA, $iv);
			$calcmac = hash_hmac('sha256', $ciphertext_raw, $key, $as_binary=true);
			if (hash_equals($hmac, $calcmac))
			{
				//echo "The decrypted string is: ".$original_plaintext."\n";
				echo "<h2>The decrypted string is: ".$original_plaintext."</h2>";
			}
		} else {
			echo "<script type='text/javascript'>
			alert('Error in retreiving cryptographic information.')
			</script>";
		}
	} else {
		echo "<script type='text/javascript'>
		alert('There is no string to display.')
		</script>";
	}
	
	?>
		<br /><br />
		<button id='' class='float-center submit-button'><a href='StringInsertSecure.html' class='btn btn-warning'>Back</a></button>
	</body>
</html>