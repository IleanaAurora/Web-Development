<?php
	include("dbConnection.php");
	
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);
	
	session_start();
			
	if (!empty($_POST["username"]) && !empty($_POST["password"]))
	//if (isset($_POST['username']) && isset($_POST['password']))
	{
		$username = $_POST['username'];
		$password = $_POST['password'];
		
		if (!preg_match('/^[a-zA-Z0-9_]{4,20}$/', $username))
			echo "<script type='text/javascript'>
				alert('You have entered an invalid username.')
				</script>";
		if (!preg_match('/^[a-zA-Z0-9_]{4,20}$/', $password))
			echo "<script type='text/javascript'>
				alert('You have entered an invalid password.')
				</script>";
		else
		{
			$username = filter_var($username, FILTER_SANITIZE_STRING);
			$password = filter_var($password, FILTER_SANITIZE_STRING);

			$db->set_charset("utf8");
			$username = $db->real_escape_string($username);
			$password = $db->real_escape_string($password);
				
			//no prepared statement, this code works
			
			/*
			$result = $db->query("SELECT * FROM SecureUsers WHERE username='".$username."' AND password='".sha1($password)."'");
			if ($result->num_rows)
			{
				$row = $result->fetch_assoc();			
				$_SESSION['UserID'] = $row['SecureID'];
			}
			*/
			
			
			
			//prepared statement attempt "#2"
			
			/*
			$prep = $db->prepare("SELECT SecureID FROM SecureUsers WHERE Username=? AND Password=?");
			$prep->bind_param("ss", $username, $password);
			
			$prep->execute();
			$prep->store_result();
			$prep->bind_result($username, $password);
			$prep->fetch();
			echo "<script language='javascript'>
				alert('The num is ".$prep->num_rows."')
				</script>";
			if ($prep->num_rows >= 1)
				$_SESSION['UserID'] = 1;
			else
			{
				echo "<script language='javascript'>
				alert('LOGIN FAILURE: Invalid username and password.')
				</script>";
			}
			*/
			
			
			
			//prepared statement attempt "#3"
			
			$query = "SELECT SecureID FROM SecureUsers WHERE Username=? AND Password=?";
			if($prep = $db->prepare($query))
			//if($prep = $db->prepare("SELECT SecureID FROM SecureUsers WHERE Username=? AND Password=?"))
			{
				$prep->bind_param('ss', $username, $password);
				if($prep->execute())
				{
					$prep->store_result();
					$prep->bind_result($SecureID);
					$num = $prep->num_rows;
					
					echo "<script language='javascript'>
				alert('The num is ".$prep->num_rows."')
				</script>";
				
					if($prep->num_rows > 0)
					{
						$_SESSION['UserID'] = $SecureID;
					}
					else
					{
						echo "<script language='javascript'>
						alert('LOGIN FAILURE: Invalid username and password.')
						</script>";
					}
				}
			}
		}	
		$db->close();
		
		//prepared statement attempt "#1"
		
		/*
		$prep = $db->prepare("SELECT SecureID FROM SecureUsers WHERE Username=? AND Password=?");
		$prep->bind_param("ss", $username, $password);

		$username = $_POST['username'];
		$password = $_POST['password'];		
		
		$username = filter_var($username, FILTER_SANITIZE_STRING);
		$password = filter_var($password, FILTER_SANITIZE_STRING);

		$db->set_charset("utf8");
		$username = $db->real_escape_string($username);
		$password = $db->real_escape_string($password);
		
		$prep->execute();
		$prep->store_result();
		
		if ($prep->num_rows === 1)
			$_SESSION['UserID'] = 1;
		else
			echo "<script type='text/javascript'>
				alert('Wrong username and password.')
				</script>";
				*/
	}
	else
	{
		//if (isset($username))
		if (isset($_POST['username']))
		{
			if ((isset($_POST['username'])!="") && (isset($_POST['password'])==""))
			{
				echo "<script language='javascript'>
				alert('LOGIN FAILURE: You must provide a valid password.')
				</script>";
			}
			else
			{
				echo "<script language='javascript'>
				alert('LOGIN FAILURE: Please enter a valid username and password.')
				</script>";
			}
		}
	}
	if (isset($_SESSION['UserID']))
	{
		echo "<script type='text/javascript'>
			alert('LOGIN SUCCESSFUL.')
			</script>";
	}
	
	// Unset all of the session variables
	$_SESSION = array();
	 
	// Destroy the session.
	session_destroy();
	
?>

<!DOCTYPE html>
<html>
    
<head>
	<title>Login</title>
</head>
<!--Template by Mutiullah Samim-->
<body>
	<form method='POST' action='index.php'>
	<h1><b><label class="header-text" for="username">SECURE USER LOGIN</label></b></h1>
		<div class="input-group mb-3">
			<div class="input-group-append">
				<span class="input-group-text"><i class="fas fa-user"></i></span>
			</div>
			<input type="text" name="username" class="form-control input_user" value="" placeholder="username">
		</div>
		<div class="input-group mb-2">
			<div class="input-group-append">
				<span class="input-group-text"><i class="fas fa-key"></i></span>
			</div>
			<input type="password" name="password" class="form-control input_pass" value="" placeholder="password">
		</div>
			<div class="d-flex justify-content-center mt-3 login_container">
	<button type="submit" name="button" class="btn login_btn">Login</button>
   </div>
	</form>
</body>
</html>