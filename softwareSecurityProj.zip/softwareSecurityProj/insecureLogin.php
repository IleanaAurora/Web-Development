<?php
	include("dbConnection.php");
	
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);
	
	session_start();
		
	if (!empty($_GET["username"]) && !empty($_GET["password"]))
	{
		$username = $_GET['username'];
		$password = $_GET['password'];
		
		$result = $db->query("SELECT * FROM InsecureUsers WHERE username='".$username."' AND password='".$password."'");
		if ($result->num_rows)
		{
			$row = $result->fetch_assoc();			
			$_SESSION['UserID'] = $row['InsecureID'];
		}
		else
		{
			echo "<script language='javascript'>
			alert('LOGIN FAILURE: Invalid username and password.')
			</script>";
		}
				
			
		$db->close();
	}
	else
	{
		if (isset($_GET['username']))
		{
			if ((isset($_GET['username'])!="") && (isset($_GET['password'])==""))
			{
				echo "<script language='javascript'>
				alert('LOGIN FAILURE: You must provide a valid password.')
				</script>";
			}
			else
			{
				echo "<script language='javascript'>
				alert('LOGIN FAILURE: Please enter a valid username and password.')
				</script>";
			}
		}
	}
	if (isset($_SESSION['UserID']))
	{
		echo "<script type='text/javascript'>
			alert('LOGIN SUCCESSFUL.')
			</script>";
			
		echo "<script type='text/javascript'>
			window.location.href = './StringInsertInsecure.html';
			</script>";
	}
	
	// Unset all of the session variables
	//$_SESSION = array();
	 
	// Destroy the session.
	//session_destroy();
	
?>


<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Login</title>
		<style>
		<?php include 'main.css'; ?>
		</style>
	</head>
	<body>
		<div id="logo">
			<img src="iona.jpg" alt='Official logo' width='180px' height='60px'>
		</div>
		<br /><br />
		<form action= "insecureLogin.php" method="get">
		<h1><b><label for="username">INSECURE USER LOGIN</label></b></h1>
			<p>
				<label for="username"><b>Username:</b></label>
				<input type="text" name="username" value="">​<br>
				<label for="password"><b>Password:</b></label>
				<input type="password" name="password" value="">​<br>
			</p>
			
			<p>
				<input type="submit" name="Submit" value="Login">
			</p>
		</form>
		<button id="" class="float-center submit-button" ><a href="index.php" class="btn btn-warning">Back to the Welcome Page</a></button>
	</body>
</html>