<?php
$output = e_d("d","Decrypt","2p3oqqR5RVd29UGAks4YtIOyLBUx5JN2B/Fghuz36Sg=");
echo $output;

function e_d($act, $str, $key) {
    $iv = md5(md5($key));  
    $out = false;
    if($act == 'd'){
        $out = mcrypt_decrypt(MCRYPT_RIJNDAEL_256, md5($key), base64_decode($str), MCRYPT_MODE_CBC, $iv);
        $out = rtrim($out, "");
    }
    else if( $act == 'e' ) {
        $out = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, md5($key), $str, MCRYPT_MODE_CBC, $iv);
        $out = base64_encode($out);
    }
    return $out;
}
?>