<?php
	include("dbConnection.php");
	
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);
	
	session_start();
			
	if (!empty($_POST["username"]) && !empty($_POST["password"]))
	{
		$username = $_POST['username'];
		$password = $_POST['password'];
		
		if (!preg_match('/^[a-zA-Z0-9_]{4,20}$/', $username))
			echo "<script type='text/javascript'>
				alert('You have entered an invalid username.')
				</script>";
		if (!preg_match('/^[a-zA-Z0-9_]{4,20}$/', $password))
			echo "<script type='text/javascript'>
				alert('You have entered an invalid password.')
				</script>";
		else
		{
			$username = filter_var($username, FILTER_SANITIZE_STRING);
			$password = filter_var($password, FILTER_SANITIZE_STRING);

			$db->set_charset("utf8");
			$username = $db->real_escape_string($username);
			$password = $db->real_escape_string($password);
			$password = sha1($password);
							
			if($prep = $db->prepare("SELECT SecureID FROM SecureUsers WHERE Username=? AND Password=?")){
				$prep->bind_param("ss", $username, $password);
				$prep->execute();
				$prep->store_result();
				$prep->bind_result($SecureID);
				$prep->fetch();
				if ($prep->num_rows === 1)
					$_SESSION['UserID'] = $SecureID;
				else
					echo "<script type='text/javascript'>
						alert('Wrong username and password.')
						</script>";
				$prep->close();
			}
		}	
		$db->close();
	}
	else
	{
		if (isset($_POST['username']))
		{
			if ((isset($_POST['username'])!="") && (isset($_POST['password'])==""))
			{
				echo "<script language='javascript'>
				alert('LOGIN FAILURE: You must provide a valid password.')
				</script>";
			}
			else
			{
				echo "<script language='javascript'>
				alert('LOGIN FAILURE: Please enter a valid username and password.')
				</script>";
			}
		}
	}
	if (isset($_SESSION['UserID']))
	{
		echo "<script type='text/javascript'>
			alert('LOGIN SUCCESSFUL.')
			</script>";
	}
	
	// Unset all of the session variables
	$_SESSION = array();
	 
	// Destroy the session.
	session_destroy();
	
?>

<!DOCTYPE html>
<html>
    
<head>
	<title>Login</title>
</head>
<body>
	<form method='POST' action='index.php'>
	<h1><b><label class="header-text" for="username">SECURE USER LOGIN</label></b></h1>
		<div class="input-group mb-3">
			<div class="input-group-append">
				<span class="input-group-text"><i class="fas fa-user"></i></span>
			</div>
			<input type="text" name="username" class="form-control input_user" value="" placeholder="username">
		</div>
		<div class="input-group mb-2">
			<div class="input-group-append">
				<span class="input-group-text"><i class="fas fa-key"></i></span>
			</div>
			<input type="password" name="password" class="form-control input_pass" value="" placeholder="password">
		</div>
			<div class="d-flex justify-content-center mt-3 login_container">
	<button type="submit" name="button" class="btn login_btn">Login</button>
   </div>
	</form>
</body>
</html>