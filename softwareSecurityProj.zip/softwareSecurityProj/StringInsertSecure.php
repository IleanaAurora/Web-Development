<html>
	<head>
		<style>
		<?php include 'main.css'; ?>
		</style>
	</head>
	<body>
		<div id="logo">
			<img src="iona.jpg" alt='Official logo' width='180px' height='60px'>
		</div>
		<br /><br />
	</body>
</html>
<?php
	include("dbConnection.php");
	
	session_start();
	
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);
	
	if (isset($_SESSION['UserID']))
	{
		$ID = $_SESSION['UserID'];
	}

	$StringIn = $_POST['stringIn'];
	
	if (preg_match('/^[a-zA-Z0-9_]$/', $StringIn))
	{
		echo "<script type='text/javascript'>
			alert('You have entered an invalid string. Only an alphanumeric string is acceptable.')
			</script>";
				
		echo "<script type='text/javascript'>
				window.location.href = './StringInsertSecure.html';
				</script>";
				
	}
	
	$StringIn = filter_var($StringIn, FILTER_SANITIZE_STRING);
	
	$db->set_charset("utf8");	
	$StringIn = $db->real_escape_string($StringIn);
	
	$ivlen = openssl_cipher_iv_length($cipher="AES-128-CBC");
	$iv = openssl_random_pseudo_bytes($ivlen);
	$salt = bin2hex($iv);
	$key = "Kevin";
	
	$ciphertext_raw = openssl_encrypt($StringIn, $cipher, $key, $options=OPENSSL_RAW_DATA, $iv);	
	$hmac = hash_hmac('sha256', $ciphertext_raw, $key, $as_binary=true);
	$StringIn = base64_encode( $iv.$hmac.$ciphertext_raw );
	
	$query = "INSERT INTO EncryptionInfo (eKey, vector, vectorLength, SecureID) VALUES(?, ?, ?, ?)";
		
	if($prep = $db->prepare("UPDATE SecureUsers SET StringInputSecure =? WHERE SecureID =?")){
		$prep->bind_param("ss", $StringIn, $ID);
		$prep->execute();
		$prep->close();
		
		echo "<script type='text/javascript'>
		alert('String saved successfully.')
		</script>";
		
		$query = "INSERT INTO EncryptionInfo (eKey, vector, vectorLength, SecureID) VALUES(?, ?, ?, ?)";
		if($stmt = $db->prepare("INSERT INTO EncryptionInfo (eKey, vector, vectorLength, SecureID) VALUES(?, ?, ?, ?)"))
		{
			$stmt->bind_param("ssii", $key, $salt, $ivlen, $ID);
			$stmt->execute();
			$stmt->close();
		
				echo "<script type='text/javascript'>
			alert('Successfully saved encryption related data.')
			</script>";
			
			echo "<script type='text/javascript'>
				window.location.href = './SecureStringDisplay.php';
				</script>";
				
		} else {
			echo "<script type='text/javascript'>
		alert('Error saving encryption related data.')
		</script>";
		
		echo "<script type='text/javascript'>
				window.location.href = './StringInsertSecure.html';
				</script>";
		}
			
	} else {
		echo "<script type='text/javascript'>
				alert('Could not save this string.')
				</script>";
				
		echo "<script type='text/javascript'>
				window.location.href = './StringInsertSecure.html';
				</script>";
	}
	

?>

