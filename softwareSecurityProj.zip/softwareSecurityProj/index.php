<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Welcome</title>
		<style>
		<?php include 'main.css'; ?>
		</style>
	</head>
	<body>
		<div id="logo">
			<img src="iona.jpg" alt='Official logo' width='180px' height='60px'>
		</div>
		<br /><br />
		<form action= "index.php" method="get">
		<h1><b><label for="username">Welcome to Our Software Security Project Web App!</label></b></h1>
		<h3>Please choose a login.</h3>
			<p>
				<button id="secureBtn" class="float-left submit-button" ><a href="secureLogin.php" class="btn btn-warning">Secure Login</a></button>
				<button id="insecureBtn" class="float-center submit-button" ><a href="insecureLogin.php" class="btn btn-warning">Insecure Login</a></button>
			</p>
		</form>
	</body>
</html>