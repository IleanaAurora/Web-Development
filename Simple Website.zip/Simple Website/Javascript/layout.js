function displayItem(n)
{
	for (i=0; i<26; i++)
	{
		if (i == n)
			document.getElementById("item"+i).style.display = "block";
		else
			document.getElementById("item"+i).style.display = "none";
	}
}