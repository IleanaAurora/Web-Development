<?php
session_start();
include("dbConnection.php");
if (isset($_SESSION['UserID']))
{
	$currUserID = $_SESSION['UserID'];
}
else
{
	echo "<script type='text/javascript'>
			window.location.href = './logout.php';
			</script>";
}
?>

<!DOCTYPE html>
<html>
    <head>
 	<title>Create Performer</title>
	<?php include './Design/head.html'; ?>
	<link href="CSS/main.css" rel="stylesheet">
	</head>
   <body>
		<?php include './Design/navBar.html';
		
		echo "	<br/>";
		echo "	<h5>&nbsp;&nbsp;&nbsp;Fill out the following fields to create a new performer: </h5>";
		echo "	<h6><font color='red'>&nbsp;&nbsp;&nbsp;&nbsp;Please fill out all required fields marked with a *.</font></h6>";
		echo "	<br/>";
		
		
	echo "	<form enctype='multipart/form-data' class='ml-3 mr-sm-2' action='Form Handlers/createPerformerHandler.php' method='post'>
	
		<div class='form-row mb-2 mr-sm-2'>
			<h6>General Information:</h6>			
		</div>
	
		<div class='form-row mb-2 mr-sm-2'>
	  
			<div class='form-group col-md-6'>
				<label for='inputPName'>Performer Name*</label>
				<input name='name' type='name' class='form-control' id='inputPName' placeholder='Name' required>
			</div>
			
			<div class='form-group col-md-2'>
				<label for='inputFees'>Performer Fees*</label>
				<input name='fees' type='number' class='form-control' id='inputFees' oninput='this.value = Math.abs(this.value)' placeholder='Dollar Amount ($)' min='0' max='1000000' step='1' required>
			</div>
			
			<div class='form-group col-md-2'>
				<label for='inputExpAudienceSize'>Expected Audience Size*</label>
				<input name='expASize' type='number' class='form-control' id='inputExpAudienceSize' oninput='this.value = Math.abs(this.value)' min='0' placeholder='Audience Size' step='1' required>
			</div>
			
		</div>
			
		<div class='form-row mb-2 mr-sm-2'>
		
			<div class='form-group col-md-6'>
				<label for='inputDescription'>Description</label>
				<textarea name='description' class='form-control' id='inputPDescription' rows='3' placeholder='Describe this performer...'></textarea>
			 </div>
			
		</div>
		
		<div class='form-row mb-2 mr-sm-2'>
			<h6>Contact Information:</h6>			
		</div>
		
		<div class='form-row mb-2 mr-sm-2'>
		
			<div class='form-group col-md-2'>
				<label for='inputPhone'>Phone Number*</label>
				<input name='phone' type='tel' class='form-control' id='inputPhone' placeholder='xxx-xxx-xxxx' pattern='\d*' minlength='10' maxlength='11' required>
			</div>
			
			<div class='form-group col-md-2'>
				<label for='inputEmail'>Email*</label>
				<input name='email' type='email' class='form-control' id='inputEmail' placeholder='name@email.com' required>
			</div>
			
		</div>
		
		<div class='form-row mb-2 mr-sm-2'>
			<h6>Select an Image:</h6>			
		</div>
		
		<div class='form-row mb-4 mr-sm-2'>
		
			<div class='custom-file'>
				<input name='img' type='file' class='custom-file-input' id='img' accept='image/jpeg'>
				<label class='custom-file-label' for='validatedCustomFile'>Choose file...</label>
				<div class='invalid-feedback'>Invalid image file.</div>
			 </div>
		</div>
		
		
	  <button type='submit' class='btn btn-info mb-4'>Create</button>
	  </form>";
		
		
		
		?>
		
	  
		
   </body>
</html>