<?php
session_start();
include("../dbConnection.php");
if (isset($_SESSION['UserID']))
{
	$currUserID = $_SESSION['UserID'];
}
else
{
	echo "<script type='text/javascript'>
			window.location.href = './logout.php';
			</script>";
}


		ini_set('display_errors', 1);
		ini_set('display_startup_errors', 1);
		error_reporting(E_ALL);


		
if(isset($_POST['editClient'])) {
	if( $_POST['editClient'] ) {
	
		$clientID = $_POST['editClient'];

		$name = $_POST["CName"];
		$name = filter_var($name, FILTER_SANITIZE_STRING);
		
		$phone = $_POST["phone"];
		if (is_numeric($phone)) {
			$phone = (int) $phone;
		} else {
			echo "Error: Provided Phone Number is NOT numeric.", PHP_EOL;
		}
		
		$email = $_POST["email"];
		$email = filter_var($email, FILTER_SANITIZE_EMAIL);	
		if (filter_var($email, FILTER_VALIDATE_EMAIL) == false) 
			$email = "Error: Provided Email is NOT valid.";
		
		$qry = "UPDATE Clients SET CName='$name',CPhone='$phone',CEmail='$email' WHERE ClientID='$clientID'";
		
		if($db->query($qry) == TRUE)
		{
			echo "<script language='javascript'>
				alert('Client Updated')
				window.location.href = '../clients.php';
				</script>";
		}
		else { echo "Error: " . $qry . "<br>" . $db->error;	}
		
		
		$db->close();

	}
}
elseif(isset($_POST['editPerformer'])) {
	if( $_POST['editPerformer'] ) {
		
		$performerID = $_POST['editPerformer'];
		
		$img = $_FILES["img"]["name"];

		$name = $_POST["name"];
		$name = filter_var($name, FILTER_SANITIZE_STRING);
		
		$description = $_POST["description"];
		$description = filter_var($description, FILTER_SANITIZE_STRING);
		
		$fees = $_POST["fees"];
		if (is_numeric($fees)) {
			$fees = (int) $fees;
		} else {
			echo "Error: Provided Performer Fees value is NOT numeric.", PHP_EOL;
		}
		
		$phone = $_POST["phone"];
		if (is_numeric($phone)) {
			$phone = (int) $phone;
		} else {
			echo "Error: Provided Phone Number is NOT numeric.", PHP_EOL;
		}
		
		$email = $_POST["email"];
		$email = filter_var($email, FILTER_SANITIZE_EMAIL);	
		if (filter_var($email, FILTER_VALIDATE_EMAIL) == false) 
			$email = "Error: Provided Email is NOT valid.";
		
		$size = $_POST["expASize"];
		if (is_numeric($size)) {
			$size = (int) $size;
		} else {
			echo "Error: Provided Expected Audience Size is NOT numeric.", PHP_EOL;
		}		
		
		if($img == '') {
			$qry = "UPDATE Performer SET PName='$name',PDescription='$description',Fees='$fees',ExpAudienceSize='$size',PPhone='$phone',PEmail='$email' WHERE PerformerID='$performerID'";
		}
		else {
			$PName = str_replace("'", '', $_POST['name']);
			$PName = str_replace(" ", '_', $_POST['name']);
		
			$path='C:\\wamp64\\www\\eventHandler\\Images\\Performers\\'.$PName.'\\';
			$fName = $path."1.jpg";
			
			if (!file_exists($path))
				mkdir($path, 0777, true);
			
			if ($_FILES["img"]["size"] > 15000000) 
			{
				echo "<script language='javascript'>
				alert('Sorry, your file is too large.')
				</script>";
			}
			else if ($_FILES['img']['error'] > 0) 
			{
				echo 'Error: '.$_FILES['img']['error'].'<br>';
			}
			else 
			{
				move_uploaded_file($_FILES['img']['tmp_name'], $fName);
			}
			$PName = str_replace("'", '', $_POST['name']);
			$img = 'Images/Performers/'.$PName.'/';
			
			$qry = "UPDATE Performer SET PName='$name',PDescription='$description',Fees='$fees',ExpAudienceSize='$size',PPhone='$phone',PEmail='$email',PImages='$img' WHERE PerformerID='$performerID'";
		}
		
		
		if($db->query($qry) == TRUE)
		{
			echo "<script language='javascript'>
				alert('Performer Updated')
				window.location.href = '../performers.php';
				</script>";
		}
		else { echo "Error: " . $qry . "<br>" . $db->error;	}
		
		
		$db->close();

	}
}
elseif(isset($_POST['editVenue'])) {
	if( $_POST['editVenue'] ) {
		
		$venueID = $_POST['editVenue'];
		
		$img = $_FILES["img"]["name"];

		$name = $_POST["name"];
		$name = filter_var($name, FILTER_SANITIZE_STRING);
		
		$cost = $_POST["cost"];
		if (is_numeric($cost)) {
			$cost = (int) $cost;
		} else {
			echo "Error: Provided Venue Cost value is NOT numeric.", PHP_EOL;
		}
		
		$capacity = $_POST["capacity"];
		if (is_numeric($capacity)) {
			$capacity = (int) $capacity;
		} else {
			echo "Error: Provided Venue Capacity value is NOT numeric.", PHP_EOL;
		}
		
		$street = $_POST["street"];
		$street = filter_var($street, FILTER_SANITIZE_STRING);
		
		$city = $_POST["city"];
		$city = filter_var($city, FILTER_SANITIZE_STRING);
		
		$state = $_POST["state"];
		$state = filter_var($state, FILTER_SANITIZE_STRING);
		
		$zip = $_POST["zip"];
		if (is_numeric($zip)) {
			$zip = (int) $zip;
		} else {
			echo "Error: Provided Venue Zip value is NOT numeric.", PHP_EOL;
		}
		
		$address = $street. ", " .$city. ", " .$state. " " .$zip;
		
		$phone = $_POST["phone"];
		if (is_numeric($phone)) {
			$phone = (int) $phone;
		} else {
			echo "Error: Provided Phone Number is NOT numeric.", PHP_EOL;
		}
		
		$email = $_POST["email"];
		$email = filter_var($email, FILTER_SANITIZE_EMAIL);	
		if (filter_var($email, FILTER_VALIDATE_EMAIL) == false) 
			$email = "Error: Provided Email is NOT valid.";
		
		$equip = $_POST["equip"];
		$equip = filter_var($equip, FILTER_SANITIZE_STRING);
		
		$description = $_POST["description"];
		$description = filter_var($description, FILTER_SANITIZE_STRING);
				
		if($img == '') {
			$qry = "UPDATE Venue SET VName='$name',VDescription='$description',Capacity='$capacity',RentalCost='$cost',AvailableEquip='$equip',Address='$address',VPhone='$phone',VEmail='$email' WHERE VenueID='$venueID'";
		}
		else {
			$VName = str_replace("'", '', $_POST['name']);
			$VName = str_replace(" ", '_', $_POST['name']);
	
		$path='C:\\wamp64\\www\\eventHandler\\Images\\Venues\\'.$VName.'\\';
		$fName = $path."1.jpg";
		
		if (!file_exists($path))
			mkdir($path, 0777, true);
		
		if ($_FILES["img"]["size"] > 15000000) 
		{
			echo "<script language='javascript'>
			alert('Sorry, your file is too large.')
			</script>";
		}
		else if ($_FILES['img']['error'] > 0) 
		{
			echo 'Error: '.$_FILES['img']['error'].'<br>';
		}
		else 
		{
			move_uploaded_file($_FILES['img']['tmp_name'], $fName);
		}
		$VName = str_replace("'", '', $_POST['name']);
		$img = 'Images/Venues/'.$VName.'/';
			
			$qry = "UPDATE Venue SET VName='$name',VDescription='$description',Capacity='$capacity',RentalCost='$cost',AvailableEquip='$equip',Address='$address',VPhone='$phone',VEmail='$email',VImages='$img' WHERE VenueID='$venueID'";
		}
		
		
		if($db->query($qry) == TRUE)
		{
			echo "<script language='javascript'>
				alert('Venue Updated')
				window.location.href = '../venues.php';
				</script>";
		}
		else { echo "Error: " . $qry . "<br>" . $db->error;	}
		
		
		$db->close();

	}
}
		
		
		
		?>
		