 <!DOCTYPE HTML>
<head>
</head>
<body>
<?php
session_start();
include("../dbConnection.php");
if (isset($_SESSION['UserID']))
{
	$currUserID = $_SESSION['UserID'];
}
else
{
	echo "<script type='text/javascript'>
			window.location.href = './logout.php';
			</script>";
}

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

	$img = $_FILES["img"]["name"];

	$name = $_POST["name"];
	$name = filter_var($name, FILTER_SANITIZE_STRING);
	
	$cost = $_POST["cost"];
	if (is_numeric($cost)) {
        $cost = (int) $cost;
    } else {
        echo "Error: Provided Venue Cost value is NOT numeric.", PHP_EOL;
    }
	
	$capacity = $_POST["capacity"];
	if (is_numeric($capacity)) {
        $capacity = (int) $capacity;
    } else {
        echo "Error: Provided Venue Capacity value is NOT numeric.", PHP_EOL;
    }
	
	$street = $_POST["street"];
	$street = filter_var($street, FILTER_SANITIZE_STRING);
	
	$city = $_POST["city"];
	$city = filter_var($city, FILTER_SANITIZE_STRING);
	
	$state = $_POST["state"];
	$state = filter_var($state, FILTER_SANITIZE_STRING);
	
	$zip = $_POST["zip"];
	if (is_numeric($zip)) {
        $zip = (int) $zip;
    } else {
        echo "Error: Provided Venue Zip value is NOT numeric.", PHP_EOL;
    }
	
	$address = $street. ", " .$city. ", " .$state. " " .$zip;
	
	$phone = $_POST["phone"];
	if (is_numeric($phone)) {
        $phone = (int) $phone;
    } else {
        echo "Error: Provided Phone Number is NOT numeric.", PHP_EOL;
    }
	
	$email = $_POST["email"];
	$email = filter_var($email, FILTER_SANITIZE_EMAIL);	
	if (filter_var($email, FILTER_VALIDATE_EMAIL) == false) 
		$email = "Error: Provided Email is NOT valid.";
	
	if($_POST['equip'] !== '')
	{				
		$equip = $_POST["equip"];
		$equip = filter_var($equip, FILTER_SANITIZE_STRING);
			
		if(($_POST['description'] == '') && ($img == ''))
		{
			$prep = $db->prepare("INSERT INTO Venue(VName,RentalCost,Capacity,Address,VPhone,VEmail,AvailableEquip) VALUES (?, ?, ?, ?, ?, ?, ?)");
			$prep->bind_param("siissss", $name, $cost, $capacity, $address, $phone, $email, $equip);
			
		}
		elseif(($_POST['description'] !== '') && ($img == ''))
		{			
			$description = $_POST["description"];
			$description = filter_var($description, FILTER_SANITIZE_STRING);
			
			$prep = $db->prepare("INSERT INTO Venue(VName,RentalCost,Capacity,Address,VPhone,VEmail,AvailableEquip,VDescription) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
			$prep->bind_param("siisssss", $name, $cost, $capacity, $address, $phone, $email, $equip, $description);
		}
		elseif(($_POST['description'] == '') && ($img !== ''))
		{
			image_upload();
			$VName = str_replace("'", '', $_POST['name']);
			$img = 'Images/Venues/'.$VName.'/';
			
			$prep = $db->prepare("INSERT INTO Venue(VName,RentalCost,Capacity,Address,VPhone,VEmail,AvailableEquip,VImages) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
			$prep->bind_param("siisssss", $name, $cost, $capacity, $address, $phone, $email, $equip, $img);
		
		}
		elseif(($_POST['description'] !== '') && ($img !== ''))
		{
			$description = $_POST["description"];
			$description = filter_var($description, FILTER_SANITIZE_STRING);
			
			image_upload();
			$VName = str_replace("'", '', $_POST['name']);
			$img = 'Images/Venues/'.$VName.'/';
			
			$prep = $db->prepare("INSERT INTO Venue(VName,RentalCost,Capacity,Address,VPhone,VEmail,AvailableEquip,VDescription,VImages) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
			$prep->bind_param("siissssss", $name, $cost, $capacity, $address, $phone, $email, $equip, $description, $img);
			
			
		}
	}
	
	
	elseif(!($_POST['equip']))
	{
		if(($_POST['description'] !== '') && ($img == ''))
		{
			$description = $_POST["description"];
			$description = filter_var($description, FILTER_SANITIZE_STRING);
			
			$prep = $db->prepare("INSERT INTO Venue(VName,RentalCost,Capacity,Address,VPhone,VEmail,VDescription) VALUES (?, ?, ?, ?, ?, ?, ?)");
			$prep->bind_param("siissss", $name, $cost, $capacity, $address, $phone, $email, $description);
		}
		elseif(($_POST['description'] !== '') && ($img !== ''))
		{		
			$description = $_POST["description"];
			$description = filter_var($description, FILTER_SANITIZE_STRING);
			
			image_upload();
			$VName = str_replace("'", '', $_POST['name']);
			$img = 'Images/Venues/'.$VName.'/';
			
			$prep = $db->prepare("INSERT INTO Venue(VName,RentalCost,Capacity,Address,VPhone,VEmail,VDescription,VImages) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
			$prep->bind_param("siisssss", $name, $cost, $capacity, $address, $phone, $email, $description, $img);
		}
		elseif(($_POST['description'] == '') && ($img !== ''))
		{		
			image_upload();
			$VName = str_replace("'", '', $_POST['name']);
			$img = 'Images/Venues/'.$VName.'/';
			
			$prep = $db->prepare("INSERT INTO Venue(VName,RentalCost,Capacity,Address,VPhone,VEmail,VImages) VALUES (?, ?, ?, ?, ?, ?, ?)");
			$prep->bind_param("siissss", $name, $cost, $capacity, $address, $phone, $email, $img);
		}
		else
		{
			$prep = $db->prepare("INSERT INTO Venue(VName,RentalCost,Capacity,Address,VPhone,VEmail) VALUES (?, ?, ?, ?, ?, ?)");
			$prep->bind_param("siisss", $name, $cost, $capacity, $address, $phone, $email);
		}
	}
	
	function image_upload()
	{
		$VName = str_replace("'", '', $_POST['name']);
	
		$path='C:\\wamp64\\www\\eventHandler\\Images\\Venues\\'.$VName.'\\';
		$fName = $path."1.jpg";
		
		if(file_exists($path))
		{
			echo "<script language='javascript'>
			alert('File with the same name $fName already exists')
			</script>";
		}
		
		if (!file_exists($path))
			mkdir($path, 0777, true);
		
		if ($_FILES["img"]["size"] > 15000000) 
		{
			echo "<script language='javascript'>
			alert('Sorry, your file is too large.')
			</script>";
		}
		else if ($_FILES['img']['error'] > 0) 
		{
			echo 'Error: '.$_FILES['img']['error'].'<br>';
		}
		else 
		{
			move_uploaded_file($_FILES['img']['tmp_name'], $fName);
		}
		
	}

	if($prep->execute())
	{
		echo "<script language='javascript'>
			alert('New Venue Created')
			window.location.href = '../createVenue.php';
			</script>";
	}
	else { echo "Error: " . $prep . "<br>" . $db->error;	}		//echo "Error: " . $qry . "<br>" . $db->error;
	
	$db->close();	
?>
</body>