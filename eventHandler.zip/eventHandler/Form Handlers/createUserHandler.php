<!DOCTYPE HTML>
<html>
<head>
</head>
<body>
<?php
session_start();
include("../dbConnection.php");
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (isset($_SESSION['UserID']))
{
	$currUserID = $_SESSION['UserID'];
}
else
{
	echo "<script type='text/javascript'>
			window.location.href = './logout.php';
			</script>";
}

	$username = $_POST["username"];
	$username = filter_var($username, FILTER_SANITIZE_STRING);

	$result = $db->query("SELECT * FROM Users WHERE username='".$username."'");
	if ($result->num_rows)
	{
		echo "<script language='javascript'>
		alert('Error: Username already taken. Please choose another to create a user.')
		window.location.href = '../createUser.php';
		</script>";
	}
	else
	{
		$prep = $db->prepare("INSERT INTO Users(AccountType,Username,Password) VALUES (?, ?, ?)");
		$prep->bind_param("iss", $accountType, $username, $password);

		$accountType = 1;
		
		$password = $_POST["password"];
		$password = filter_var($password, FILTER_SANITIZE_STRING);
		$password = sha1($password);
		
		if($prep->execute())
		{
			echo "<script language='javascript'>
				alert('New User Created')
				window.location.href = '../createUser.php';
				</script>";
		}
		else { echo "Error: " . $prep . "<br>" . $db->error;	}		//echo "Error: " . $qry . "<br>" . $db->error;
	}

	
	$db->close();
?>
</body>
</html>