 <!DOCTYPE HTML>
<head>
</head>
<body>
<?php
session_start();
include("../dbConnection.php");
if (isset($_SESSION['UserID']))
{
	$currUserID = $_SESSION['UserID'];
}
else
{
	echo "<script type='text/javascript'>
			window.location.href = './logout.php';
			</script>";
}


	$type = $_POST["type"];
	if (is_numeric($type)) {
        $type = (int) $type;
    } else {
        echo "Error: Provided Event Type value is NOT numeric.", PHP_EOL;
    }

	$name = $_POST["name"];
	$name = filter_var($name, FILTER_SANITIZE_STRING);
	
	$venue = $_POST["venue"];
	if (is_numeric($venue)) {
        $venue = (int) $venue;
    } else {
        echo "Error: Provided Venue value is NOT numeric.", PHP_EOL;
    }
	
	$stime = $_POST["stime"];
		
	$etime = $_POST["etime"];
		
	$duration = $_POST["duration"];
	
	$aattendees = $_POST["aattendees"];
	if (is_numeric($aattendees)) {
        $aattendees = (int) $aattendees;
    } else {
        echo "Error: Provided Actual Attendees value is NOT numeric.", PHP_EOL;
    }
	
	$cost = $_POST["cost"];
	if (is_numeric($cost)) {
        $cost = (int) $cost;
    } else {
        echo "Error: Provided Ticket Cost value is NOT numeric.", PHP_EOL;
    }
	
	$performer = $_POST["performer"];
	if (is_numeric($performer)) {
        $performer = (int) $performer;
    } else {
        echo "Error: Provided Performer value is NOT numeric.", PHP_EOL;
    }
	
	$client = $_POST["client"];
	if (is_numeric($client)) {
        $client = (int) $client;
    } else {
        echo "Error: Provided Client value is NOT numeric.", PHP_EOL;
    }
	
	if ($prep = $db->prepare("SELECT RentalCost FROM Venue WHERE VenueID=?")) {
		$prep->bind_param("i", $venue);
		$prep->execute();
		$prep->bind_result($venueCost);
		$prep->fetch();
	}
	$prep->close();
	
	if ($prep1 = $db->prepare("SELECT Fees FROM Performer WHERE PerformerID=?")) {
		$prep1->bind_param("i", $performer);
		$prep1->execute();
		$prep1->bind_result($performerFees);
		$prep1->fetch();
	}
	$prep1->close();
	
	$profit = ($aattendees * $cost) - $venueCost - $performerFees;
	
	if($_POST['eattendees'] !== '')
	{	
		$eattendees = $_POST["eattendees"];
		if (is_numeric($eattendees)) {
			$eattendees = (int) $eattendees;
		} else {
			echo "Error: Provided Estimated Attendees value $eattendees is NOT numeric.", PHP_EOL;
		}
		if(!isset($_POST['promo']) && !isset($_POST['req']))
		{
			$prep = $db->prepare("INSERT INTO Events(EName,ETypeID,ClientID,ActAttendeesNo,StartDate,EndDate,Duration,TicPrice,Profit,VenueID,PerformerID,ExpAttendeesNo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			$prep->bind_param("siiisssiiiii", $name, $type, $client, $aattendees, $stime, $etime, $duration, $cost, $profit, $venue, $performer, $eattendees);
		}
		elseif(isset($_POST['promo']) && !isset($_POST['req']))
		{			
			$promo = $_POST["promo"];
			
			$prep = $db->prepare("INSERT INTO Events(EName,ETypeID,ClientID, ActAttendeesNo,StartDate,EndDate,Duration,TicPrice,Profit,VenueID,PerformerID,ExpAttendeesNo, PromoMaterialID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			$prep->bind_param("siiisssiiiiii", $name, $type, $client, $aattendees, $stime, $etime, $duration, $cost, $profit, $venue, $performer, $eattendees, $promo);
		}
		elseif(!isset($_POST['promo']) && isset($_POST['req']))
		{
			$req = $_POST["req"];
			$req = filter_var($req, FILTER_SANITIZE_STRING);			
			
			$prep = $db->prepare("INSERT INTO Events(EName,ETypeID,ClientID,ActAttendeesNo,StartDate,EndDate,Duration,TicPrice,Profit,VenueID,PerformerID,ExpAttendeesNo,SpecialReq) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			$prep->bind_param("siiisssiiiiis", $name, $type, $client, $aattendees, $stime, $etime, $duration, $cost, $profit, $venue, $performer, $eattendees, $req);
		}
		elseif(isset($_POST['promo']) && isset($_POST['req']))
		{
			$promo = $_POST["promo"];
			
			$req = $_POST["req"];
			$req = filter_var($req, FILTER_SANITIZE_STRING);
			
			$prep = $db->prepare("INSERT INTO Events(EName,ETypeID,ClientID,ActAttendeesNo,StartDate,EndDate,Duration,TicPrice,Profit,VenueID,PerformerID,ExpAttendeesNo,PromoMaterialID,SpecialReq) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			$prep->bind_param("siiisssiiiiiis", $name, $type, $client, $aattendees, $stime, $etime, $duration, $cost, $profit, $venue, $performer, $eattendees, $promo, $req);
		}
	}
	else
	{
		if(($_POST['promo'] == '') && ($_POST['req'] == ''))
		{
			$prep = $db->prepare("INSERT INTO Events(EName,ETypeID,ClientID,ActAttendeesNo,StartDate,EndDate,Duration,TicPrice,Profit,VenueID,PerformerID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			$prep->bind_param("siiisssiiii", $name, $type, $client, $aattendees, $stime, $etime, $duration, $cost, $profit, $venue, $performer);
		}
		elseif(($_POST['promo'] !== '') && ($_POST['req'] == ''))
		{
			$promo = $_POST["promo"];
			
			$prep = $db->prepare("INSERT INTO Events(EName,ETypeID,ClientID,ActAttendeesNo,StartDate,EndDate,Duration,TicPrice,Profit,VenueID,PerformerID,PromoMaterialID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			$prep->bind_param("siiisssiiiii", $name, $type, $client, $aattendees, $stime, $etime, $duration, $cost, $profit, $venue, $performer, $promo);
		}
		elseif(($_POST['promo'] !== '') && ($_POST['req'] !== ''))
		{		
			$promo = $_POST["promo"];
			
			$req = $_POST["req"];
			$req = filter_var($req, FILTER_SANITIZE_STRING);
			
			$prep = $db->prepare("INSERT INTO Events(EName,ETypeID,ClientID,ActAttendeesNo,StartDate,EndDate,Duration,TicPrice,Profit,VenueID,PerformerID,PromoMaterialID,SpecialReq) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			$prep->bind_param("siiisssiiiiis", $name, $type, $client, $aattendees, $stime, $etime, $duration, $cost, $profit, $venue, $performer, $promo, $req);
		}
		elseif(($_POST['promo'] == '') && ($_POST['req'] !== ''))
		{		
			$req = $_POST["req"];
			$req = filter_var($req, FILTER_SANITIZE_STRING);
			
			$prep = $db->prepare("INSERT INTO Events(EName,ETypeID,ClientID,ActAttendeesNo,StartDate,EndDate,Duration,TicPrice,Profit,VenueID,PerformerID,SpecialReq) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			$prep->bind_param("siiisssiiiis", $name, $type, $client, $aattendees, $stime, $etime, $duration, $cost, $profit, $venue, $performer, $req);
		}
	}

	
	if($prep->execute())
	{
		echo "<script language='javascript'>
			alert('New Event Created')
			window.location.href = '../scheduling.php';
			</script>";
	}
	else { echo "Error: " . $qry . "<br>" . $db->error;	}
	
	$db->close();	
?>
</body>