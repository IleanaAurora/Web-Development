<!DOCTYPE HTML>
<html>
<head>
</head>
<body>
<?php
session_start();
include("../dbConnection.php");
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (isset($_SESSION['UserID']))
{
	$currUserID = $_SESSION['UserID'];
}
else
{
	echo "<script type='text/javascript'>
			window.location.href = './logout.php';
			</script>";
}

	$userID = $_POST["user"];
	
	$password = $_POST["password"];
	$password = filter_var($password, FILTER_SANITIZE_STRING);
	$password = sha1($password);
	
	$qry = "UPDATE Users SET Password='$password' WHERE UserID='$userID'";
	
	if($db->query($qry) == TRUE)
	{
		echo "<script language='javascript'>
			alert('Password Updated.')
			window.location.href = '../changePassword.php';
			</script>";
	}
	else { echo "Error: " . $qry . "<br>" . $db->error;	}		//echo "Error: " . $qry . "<br>" . $db->error;

	
	$db->close();
?>
</body>
</html>