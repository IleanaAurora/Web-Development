<!DOCTYPE HTML>
<head>
</head>
<body>
<?php
session_start();
include("../dbConnection.php");
if (isset($_SESSION['UserID']))
{
	$currUserID = $_SESSION['UserID'];
}
else
{
	echo "<script type='text/javascript'>
			window.location.href = './logout.php';
			</script>";
}


	$img = $_FILES["img"]["name"];

	$name = $_POST["name"];
	$name = filter_var($name, FILTER_SANITIZE_STRING);
	
	$fees = $_POST["fees"];
	if (is_numeric($fees)) {
        $fees = (int) $fees;
    } else {
        echo "Error: Provided Performer Fees value is NOT numeric.", PHP_EOL;
    }
	
	$phone = $_POST["phone"];
	if (is_numeric($phone)) {
        $phone = (int) $phone;
    } else {
        echo "Error: Provided Phone Number is NOT numeric.", PHP_EOL;
    }
	
	$email = $_POST["email"];
	$email = filter_var($email, FILTER_SANITIZE_EMAIL);	
	if (filter_var($email, FILTER_VALIDATE_EMAIL) == false) 
		$email = "Error: Provided Email is NOT valid.";
	
	$size = $_POST["expASize"];
	if (is_numeric($size)) {
		$size = (int) $size;
	} else {
		echo "Error: Provided Expected Audience Size is NOT numeric.", PHP_EOL;
	}		
		
	if($_POST['description'] == '' && ($img == ''))
	{
		$prep = $db->prepare("INSERT INTO Performer(PName,Fees,PPhone,PEmail,ExpAudienceSize) VALUES (?, ?, ?, ?, ?)");
		$prep->bind_param("sissi", $name, $fees, $phone, $email, $size);
	}
	elseif($_POST['description'] !== '' && ($img == ''))
	{			
		$description = $_POST["description"];
		$description = filter_var($description, FILTER_SANITIZE_STRING);
		
		$prep = $db->prepare("INSERT INTO Performer(PName,Fees,PPhone,PEmail,ExpAudienceSize,PDescription) VALUES (?, ?, ?, ?, ?, ?)");
		$prep->bind_param("sissis", $name, $fees, $phone, $email, $size, $description);
	}
	elseif($_POST['description'] == '' && ($img !== ''))
	{
		image_upload();
		$PName = str_replace("'", '', $_POST['name']);
		$img = 'Images/Performers/'.$PName.'/';
		
		$prep = $db->prepare("INSERT INTO Performer(PName,Fees,PPhone,PEmail,ExpAudienceSize, PImages) VALUES (?, ?, ?, ?, ?, ?)");
		$prep->bind_param("sissis", $name, $fees, $phone, $email, $size, $img);
	}
	elseif($_POST['description'] !== '' && ($img !== ''))
	{
		$description = $_POST["description"];
		$description = filter_var($description, FILTER_SANITIZE_STRING);
		
		image_upload();
		$PName = str_replace("'", '', $_POST['name']);
		$img = 'Images/Performers/'.$PName.'/';
		
		$prep = $db->prepare("INSERT INTO Performer(PName,Fees,PPhone,PEmail,ExpAudienceSize, PDescription, PImages) VALUES (?, ?, ?, ?, ?, ?, ?)");
		$prep->bind_param("sississ", $name, $fees, $phone, $email, $size, $description, $img);
	}
	
	
		function image_upload()
	{
		$PName = str_replace("'", '', $_POST['name']);
		$PName = str_replace(" ", '_', $_POST['name']);
	
		$path='C:\\wamp64\\www\\eventHandler\\Images\\Performers\\'.$PName.'\\';
		$fName = $path."1.jpg";
		
		if(file_exists($path))
		{
			echo "<script language='javascript'>
			alert('File with the same name $fName already exists')
			</script>";
		}
		
		if (!file_exists($path))
			mkdir($path, 0777, true);
		
		if ($_FILES["img"]["size"] > 15000000) 
		{
			echo "<script language='javascript'>
			alert('Sorry, your file is too large.')
			</script>";
		}
		else if ($_FILES['img']['error'] > 0) 
		{
			echo 'Error: '.$_FILES['img']['error'].'<br>';
		}
		else 
		{
			move_uploaded_file($_FILES['img']['tmp_name'], $fName);
		}
		
	}
	
	
	if($prep->execute())
	{
		echo "<script language='javascript'>
			alert('New Performer Created')
			window.location.href = '../createPerformer.php';
			</script>";
	}
	else { echo "Error: " . $prep . "<br>" . $db->error;	}		//echo "Error: " . $qry . "<br>" . $db->error;
	
	$db->close();
	
	
?>
</body>