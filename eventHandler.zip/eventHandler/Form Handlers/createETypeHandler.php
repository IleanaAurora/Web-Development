<!DOCTYPE HTML>
<head>
</head>
<body>
<?php
session_start();
include("../dbConnection.php");

if (isset($_SESSION['UserID']))
{
	$currUserID = $_SESSION['UserID'];
}
else
{
	echo "<script type='text/javascript'>
			window.location.href = './logout.php';
			</script>";
}


	$prep = $db->prepare("INSERT INTO EType(EType,SuggestedStartTime) VALUES (?, ?)");
	$prep->bind_param("ss", $name, $time);

	$name = $_POST["eventName"];
	$name = filter_var($name, FILTER_SANITIZE_STRING);
	
	$time24 = $_POST["suggStartTime"];
	$time = date("H:i:s",strtotime($time24));
	
	if($prep->execute())
	{
		echo "<script language='javascript'>
			alert('New EType Created')
			window.location.href = '../createEType.php';
			</script>";
	}
	else { echo "Error: " . $prep . "<br>" . $db->error;	}		//echo "Error: " . $qry . "<br>" . $db->error;
	
	
	$db->close();
?>
</body>