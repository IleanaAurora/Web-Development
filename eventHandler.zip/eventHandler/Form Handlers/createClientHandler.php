<!DOCTYPE HTML>
<head>
</head>
<body>
<?php
session_start();
include("../dbConnection.php");
if (isset($_SESSION['UserID']))
{
	$currUserID = $_SESSION['UserID'];
}
else
{
	echo "<script type='text/javascript'>
			window.location.href = './logout.php';
			</script>";
}


	$prep = $db->prepare("INSERT INTO Clients(CName,CPhone,CEmail) VALUES (?, ?, ?)");
	$prep->bind_param("sss", $name, $phone, $email);

	$name = $_POST["CName"];
	$name = filter_var($name, FILTER_SANITIZE_STRING);
	
	$phone = $_POST["phone"];
	if (is_numeric($phone)) {
        $phone = (int) $phone;
    } else {
        echo "Error: Provided Phone Number is NOT numeric.", PHP_EOL;
    }
	
	$email = $_POST["email"];
	$email = filter_var($email, FILTER_SANITIZE_EMAIL);	
	if (filter_var($email, FILTER_VALIDATE_EMAIL) == false) 
		$email = "Error: Provided Email is NOT valid.";
	
	if($prep->execute())
	{
		echo "<script language='javascript'>
			alert('New Client Created')
			window.location.href = '../createClient.php';
			</script>";
	}
	else { echo "Error: " . $prep . "<br>" . $db->error;	}		//echo "Error: " . $qry . "<br>" . $db->error;
	
	
	$db->close();
?>
</body>