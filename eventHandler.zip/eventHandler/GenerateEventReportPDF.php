<?php
	session_start();
	include("dbConnection.php");
	require('FPDF/fpdf.php');
	if (isset($_SESSION['UserID']))
	{
		$currUserID = $_SESSION['UserID'];
	}
	else
	{
		echo "<script type='text/javascript'>
				window.location.href = './logout.php';
				</script>";
	}
	
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);
?>
<?php
	class PDF extends FPDF
	{
		var $widths;
		var $aligns;
		
		
		// DEFAULT METHODS
		function SetWidths($w)
		{
		    //Set the array of column widths
		    $this->widths=$w;
		}

		function SetAligns($a)
		{
		    //Set the array of column alignments
		    $this->aligns=$a;
		}

		function Row($data, $r, $g, $b)
		{			
		   	//Calculate the height of the row
		    $nb=0;
		    for($i=0;$i<count($data);$i++)
		        $nb=max($nb, $this->NbLines($this->widths[$i], $data[$i]));
		    $h=5*$nb;
		    //Issue a page break first if needed
		    $this->CheckPageBreak($h);
		    //Draw the cells of the row
		    for($i=0;$i<count($data);$i++)
		    {
		        $w=$this->widths[$i];
		        $a=isset($this->aligns[$i]) ? $this->aligns[$i] : 'L';
		        //Save the current position
		        $x=$this->GetX();
		        $y=$this->GetY();
		        //Draw the border
				$this->SetFillColor($r, $g, $b);
				$this->SetDrawColor(0,0,0);
				$this->SetLineWidth(.05);
		        $this->Rect($x, $y, $w-.01, $h+1, 'DF');
					
				//	$this->SetFont('','B');
		        //Print the text
		        $this->MultiCell($w, 5, $data[$i], "LTR", $a, true);
		        //Put the position to the right of the cell
		        $this->SetXY($x+$w, $y);
		    }
		    //Go to the next line
		    $this->Ln($h);
		}
		
		function CheckPageBreak($h)
		{
		    //If the height h would cause an overflow, add a new page immediately
		    if($this->GetY()+$h>$this->PageBreakTrigger)
		        $this->AddPage($this->CurOrientation);
		}

		function NbLines($w, $txt)
		{
		    //Computes the number of lines a MultiCell of width w will take
		    $cw=&$this->CurrentFont['cw'];
		    if($w==0)
		        $w=$this->w-$this->rMargin-$this->x;
		    $wmax=($w-2*$this->cMargin)*1000/$this->FontSize;
		    $s=str_replace("\r", '', $txt);
		    $nb=strlen($s);
		    if($nb>0 and $s[$nb-1]=="\n")
		        $nb--;
		    $sep=-1;
		    $i=0;
		    $j=0;
		    $l=0;
		    $nl=1;
		    while($i<$nb)
		    {
		        $c=$s[$i];
		        if($c=="\n")
		        {
		            $i++;
		            $sep=-1;
		            $j=$i;
		            $l=0;
		            $nl++;
		            continue;
		        }
		        if($c==' ')
		            $sep=$i;
		        $l+=$cw[$c];
		        if($l>$wmax)
		        {
		            if($sep==-1)
		            {
		                if($i==$j)
		                    $i++;
		            }
		            else
		                $i=$sep+1;
		            $sep=-1;
		            $j=$i;
		            $l=0;
		            $nl++;
		        }
		        else
		            $i++;
		    }
		    return $nl;
		}


		// HEADER and FOOTER - automatically executed
		function Header()
		{
		    // Logo
		    $this->Image('Images/Backgrounds/logo.jpg',10,6,25);
		    // Arial bold 18
		    $this->SetFont('Arial','B',18);
		    // Draw an empty cell to move the next text in the right corner
		    $this->Cell(80);
		    // Report title
		    $this->Cell(160,10,'Events Report',0,0,'C');
		    // Line break
		    $this->Ln(20);
		}


		function Footer()
		{
		    $this->SetY(-15);
		    $this->SetFont('Arial','I',8);
		    $this->Cell(0, 10, 'Page '.$this->PageNo().' of {nb}', 0, 0, 'L');
			$this->Cell(0, 10, date('m/d/Y H:i:s'), 0, 0, 'R');		    
		}



		// ---------- My Custom Tables ---------
		function ClientTable($header, $data, $widths)
		{
			// Color R/G/B parameters between 0 and 255 each
			//$this->SetFillColor(140, 27, 49);
			$this->SetFillColor(9, 63, 111);
			$this->SetTextColor(255); // If only one argument, it's assumed to be gray scale level. Otherwise use 3 parameters for red/green/blue values (0-255 each)
			$this->SetDrawColor(0,0,0);
			$this->SetLineWidth(.1); 
			$this->SetFont('','B');// '' means "keep current font family". 'B' is "bold"

			$w = $widths;
			for($i=0;$i<count($header);$i++)
				$this->Cell($widths[$i],7,$header[$i],1,0,'C',true);
			$this->Ln();

			$this->SetFillColor(225,234,224);
			$this->SetTextColor(0);
			$this->SetDrawColor(0,0,0);
			$this->SetFont('Arial', '', 9);
			$this->SetWidths($widths);
			
			foreach($data as $row)
			{
				$this->Row(array($row[0], $row[1]), 255, 255, 255);				  
			}

		}
		
		function EventsTable($header, $data, $widths)
		{
			// Color R/G/B parameters between 0 and 255 each
			//$this->SetFillColor(140, 27, 49);
			$this->SetFillColor(185, 28, 43);
			$this->SetTextColor(255); // If only one argument, it's assumed to be gray scale level. Otherwise use 3 parameters for red/green/blue values (0-255 each)
			$this->SetDrawColor(0,0,0);
			$this->SetLineWidth(.1); 
			$this->SetFont('','B');// '' means "keep current font family". 'B' is "bold"

			$w = $widths;
			for($i=0;$i<count($header);$i++)
				$this->Cell($widths[$i],7,$header[$i],1,0,'C',true);
			$this->Ln();

			$this->SetFillColor(225,234,224);
			$this->SetTextColor(0);
			$this->SetDrawColor(0,0,0);
			$this->SetFont('Arial', '', 9);
			$this->SetWidths($widths);
			
			foreach($data as $row)
			{
				$this->Row(array($row[0], $row[1], $row[2], $row[3], $row[4], $row[5], $row[6]), 255, 255, 255);				  
			}

		}		
	}


	//==========================    MAIN CODE   =============================


	/* ------------ Get the POST variables and access the database  ------------- */
	
   	if(isset($_GET['passClientID'])) {
		if($_GET['passClientID']!='') {
	
			$now = new DateTime(null, new DateTimeZone('America/New_York'));
			$date = $now->format('m/d/Y');
			
			$clientID = $_GET['passClientID'];
			
			$query = "SELECT * FROM Events,Clients,Venue,Performer WHERE Clients.ClientID=Events.ClientID and Venue.VenueID=Events.VenueID and Performer.PerformerID=Events.PerformerID and Events.ClientID='$clientID'";
			$result = $db->query($query);	
			$numrows = $result->num_rows;	

			$eventsArray=array();
			for ($i=0; $i<$numrows ; $i++)
			{
				$row = $result->fetch_assoc();
				$eventName = $row['EName'];
				$eventName = str_replace('&#39;','\'', $eventName);
				$clientName = $row['CName'];
				$venueName = $row['VName'];
				$venueAddr = $row['Address'];
				$venueCost = $row['RentalCost'];
				$actAttendance = $row['ActAttendeesNo'];
				$ticketCost = $row['TicPrice'];
				$performer = $row['PName'];
				$performerCost = $row['Fees'];
				$eventDate = $row['StartDate'];
				$eventDate = date( 'm/d/Y g:i A', strtotime($eventDate));
				$profit = $row['Profit'];
						
				if ($profit > 2000)
					$profit -= $profit*.15; // 15% is our event organizer cost
				else
					$profit -= 200; // If less than $2000, our flat fee is $200
				
				array_push($eventsArray, array($eventDate, $eventName, $venueName, $venueAddr, $performer, $actAttendance, $profit));		
			}	
				
			 

			/* ------------ START THE PDF GENERATION ------------- */
			$pdf = new PDF();

			$header = array('Client', 'Date');
			$data = array();
			$data[0]=array($clientName, $date);
			$widths = array(95, 95);

			// Set alias for number of pages. Will be calculated and substituted at the end.
			$pdf->AliasNbPages();	
			
			// Create new page	(Header() and Footer() functions executed automatically
			$pdf->AddPage();
			
			// Blank lines
			$pdf->Ln(5);
			
			// Default font and draw color
			$pdf->SetFont('Arial', '', 9);
			$pdf->SetDrawColor(0,0,0);
			
			// Draw the client description table.
			$pdf->ClientTable($header, $data, $widths);
			
			// Now prepare and draw the events table.
			$eventsHeader = array('Event Date', 'Event Name', 'Venue Name', 'Venue Address', 
							'Performer', 'Attendees', 'Your Profit/Loss');
			$eventWidths = array(18, 25, 25, 45, 25, 22, 30);
			$pdf->Ln(5);
			$pdf->EventsTable($eventsHeader, $eventsArray, $eventWidths);
			
			// With all the tables created, generate the actual file...
			$tempFileName = 'Report'.time().'.pdf';
			$pdf->Output('PDFs/'.$tempFileName, 'F');
			
			$qry = "UPDATE Events SET ReportPDFLoc='$tempFileName' WHERE ClientID='$clientID'";
			
			if($db->query($qry) == TRUE)
			{		}
			else { echo "Error: " . $qry . "<br>" . $db->error;	}
			
			echo "<script language='javascript'>
			alert('Document generated with name $tempFileName in the PDFs folder.')
			window.location.href = './clients.php';
			</script>";

			}
	}
	
	$db->close();
	
?>
