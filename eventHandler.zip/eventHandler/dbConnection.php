<?php
$server = 'localhost';
$dbusername = 'root';
$dbpassword = '';
$dbname = 'eventhandler';
$currUserID = 1;
// Create connection

$db = new mysqli($server, $dbusername, $dbpassword, $dbname);

// Check connection
if (mysqli_connect_errno())
{
  echo "Could not connect to the database!";
  exit;
}

?>
