<?php
	session_start();
	include("dbConnection.php");
	if (isset($_SESSION['UserID']))
{
	$currUserID = $_SESSION['UserID'];
}
else
{
	echo "<script type='text/javascript'>
			window.location.href = './logout.php';
			</script>";
}
?>


<!DOCTYPE html>
<html>
    <head>
 	<title>Change User Password</title>
	<?php include './Design/head.html'; ?>
	<link href='CSS/main.css' rel='stylesheet'>
	</head>
   <body>
		<?php include './Design/navBar2.html';
				
		
		echo "	<br/>";
		echo "	<h5>&nbsp;&nbsp;&nbsp;Fill out the following fields to change a user's password: </h5>";
		echo "	<h6><font color='red'>&nbsp;&nbsp;&nbsp;&nbsp;Please fill out all required fields marked with a *.</font></h6>";
		echo "	<br/>";
		
		
	echo "	<form class='ml-3 mr-sm-2' action='Form Handlers/changePasswordHandler.php' method='post'>
		<div class='form-row mb-2 mr-sm-2'>
	  
			<div class='form-group col-md-3'>
				<label for='username'>Username*</label>
				<select name='user' class='browser-default custom-select' id='client' aria-labelledby='dropdownMenu2' required>
					<option class='dropdown-item' value=''>Select</option>		";
					
					$qry="SELECT Username, UserID FROM Users WHERE UserID > 1";
					$result = $db->query($qry);
					$num_rows = $result->num_rows;
					for ($i=0; $i<$num_rows; $i++)
					{
						$row = $result->fetch_assoc();
						$username = $row['Username'];
						echo "<option class='dropdown-item' value='".$row['UserID']."'>".$username."</option> ";
					}			
echo "				</select>
			</div>
			
			<div class='form-group col-md-6'>
				<label for='password'>New Password*</label>
				<input name='password' type='name' id='password' class='form-control' placeholder='Username' required/>
			</div>
			
		</div>
	  <button type='submit' class='btn btn-info mb-4'>Update</button>
	  </form>";
		
		
		
		?>
		
	  
		
   </body>
</html>