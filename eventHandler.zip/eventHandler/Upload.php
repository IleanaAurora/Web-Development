<?php 
	session_start();
	include("dbConnection.php");
		if (isset($_SESSION['UserID']))
	{
		$currUserID = $_SESSION['UserID'];
	}
	else
	{
		echo "<script type='text/javascript'>
				window.location.href = './logout.php';
				</script>";
	}
?>
<?php

	$VName = $db->real_escape_string(htmlspecialchars($_POST['VName']));
	
	$path='Images/Venues/'.$VName.'/';
	if (!file_exists($path))
		mkdir($path, 0777, true);
		
	$fName = $path.$_FILES["img"]["name"];
	$fileType = pathinfo($fName, PATHINFO_EXTENSION);
	
	if(file_exists($fName))
	{
		echo "File with the same name already exists";
	}
	else if ($_FILES["img"]["size"] > 15000000) 
	{
	    echo "Sorry, your file is too large.";
	}
	else if ($_FILES['img']['error'] > 0) 
	{
        echo 'Error: '.$_FILES['img']['error'].'<br>';
    }
    else 
	{
        move_uploaded_file($_FILES['img']['tmp_name'], $path.$_FILES['img']['name']);

		$file = $_FILES["img"]["name"];		//file name

		echo "File uploaded";
   	}

	$db->close();	

?>