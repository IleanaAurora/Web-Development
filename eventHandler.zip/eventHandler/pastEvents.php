<?php
session_start();
include("dbConnection.php");
	if (isset($_SESSION['UserID']))
	{
		$currUserID = $_SESSION['UserID'];
	}
	else
	{
		echo "<script type='text/javascript'>
				window.location.href = './logout.php';
				</script>";
	}
?>

<!DOCTYPE html>
<html>
    <head>
 	<title>Past Events</title>
	<?php include './Design/head.html'; ?>
	</head>
   <body>
		<?php include './Design/navBar.html'; 
		
		
		echo "	<div class='headings'>";
		
		
		echo "	<form name='sort' action='' method='post'>";
		echo "	<select class='browser-default custom-select w-auto' name='order' class='chosen'select'>";
		echo "	   <option value='asc'>Oldest to Newest</option>";
		echo "	   <option value='desc'>Newest to Oldest</option>";
		echo "	</select>";
		echo "	<input type='submit' class='btn btn-info' value='Sort' />";
		echo "	</form>";
		echo "	</br>";
		
		
		
		$now = new DateTime(null, new DateTimeZone('America/New_York'));
		$currDate = $now->format('Y-m-d H:i:s');
		
		$sort = @$_POST['order'];
		if ((!empty($sort)) && $sort == 'desc') { // If you Sort it with value of your select options
		$qry="SELECT EName,Events.ETypeID,EType.EType,ExpAttendeesNo,ActAttendeesNo,StartDate,EndDate,SpecialReq,TicPrice,Profit,Venue.VName,Performer.PName,Clients.CName
			  FROM Events,EType,Venue,Performer,Clients
			  WHERE Events.ETypeID=EType.ETypeID and Events.VenueID=Venue.VenueID and Events.PerformerID=Performer.PerformerID and Events.ClientID=Clients.ClientID and Events.EndDate < '$currDate'
                ORDER BY EndDate DESC";
		$result = $db->query($qry);
		$num_rows = $result->num_rows;
		for ($i=0; $i<$num_rows; $i++)
		{
			$row = $result->fetch_assoc();
			echo "	<h1>Event Name: ".$row['EName']."</h1>";
			echo "  	<h2>Client: ".$row['CName']."</h2>";
			echo "  	<h2>Event Type: ".$row['EType']."</h2>";
			$unformattedDate = $row['StartDate'];
			$date = date( 'm-d-Y', strtotime($unformattedDate));
			echo "  	<h2>Date: ".$date."</h2>";
			$unformattedStime = $row['StartDate'];
			$unformattedEtime = $row['EndDate'];
			$stime = date("g:i A",strtotime($unformattedStime));
			$etime = date("g:i A",strtotime($unformattedEtime));
			echo "  	<h2>Time: ".$stime." - ".$etime."</h2>";
			echo "  	<h2>Venue: ".$row['VName']."</h2>";
			echo "  	<h2>Performer: ".$row['PName']."</h2>";
			echo "  	<h2>Ticket Price: $".$row['TicPrice']."</h2>";
			echo "  	<h2>Number of Attendees: ".$row['ActAttendeesNo']."</h2>";
			
		echo "</br>";
		echo "</br>";
		echo "</br>";
		echo "</br>";
		echo "</br>";
		}
		echo "	</div>";
		
		
		
		}
		else { 
			$qry = "SELECT EName,Events.ETypeID,EType.EType,ExpAttendeesNo,ActAttendeesNo,StartDate,EndDate,SpecialReq,TicPrice,Profit,Venue.VName,Performer.PName,Clients.CName
			  FROM Events,EType,Venue,Performer,Clients
			  WHERE Events.ETypeID=EType.ETypeID and Events.VenueID=Venue.VenueID and Events.PerformerID=Performer.PerformerID and Events.ClientID=Clients.ClientID and Events.EndDate < '$currDate' 
                ORDER BY EndDate ASC";
				
			$result = $db->query($qry);
			$num_rows = $result->num_rows;
			for ($i=0; $i<$num_rows; $i++)
			{
				$row = $result->fetch_assoc();
				echo "	<h1>Event Name: ".$row['EName']."</h1>";
				echo "  	<h2>Client: ".$row['CName']."</h2>";
				echo "  	<h2>Event Type: ".$row['EType']."</h2>";
				$unformattedDate = $row['StartDate'];
				$date = date( 'm-d-Y', strtotime($unformattedDate));
				echo "  	<h2>Date: ".$date."</h2>";
				$unformattedStime = $row['StartDate'];
				$unformattedEtime = $row['EndDate'];
				$stime = date("g:i A",strtotime($unformattedStime));
				$etime = date("g:i A",strtotime($unformattedEtime));
				echo "  	<h2>Time: ".$stime." - ".$etime."</h2>";
				echo "  	<h2>Venue: ".$row['VName']."</h2>";
				echo "  	<h2>Performer: ".$row['PName']."</h2>";
				echo "  	<h2>Ticket Price: $".$row['TicPrice']."</h2>";
				echo "  	<h2>Number of Attendees: ".$row['ActAttendeesNo']."</h2>";
				
			echo "</br>";
			echo "</br>";
			echo "</br>";
			echo "</br>";
			echo "</br>";
			}
			echo "	</div>";
			
		
		
		
				
			
		}
		?>
		
	  
		
   </body>
</html>