<?php
	session_start();
	include("dbConnection.php");
	if (isset($_SESSION['UserID']))
{
	$currUserID = $_SESSION['UserID'];
}
else
{
	echo "<script type='text/javascript'>
			window.location.href = './logout.php';
			</script>";
}
?>


<!DOCTYPE html>
<html>
    <head>
 	<title>Create New User</title>
	<?php include './Design/head.html'; ?>
	<link href='CSS/main.css' rel='stylesheet'>
	</head>
   <body>
		<?php include './Design/navBar2.html';
		
		
		echo "	<br/>";
		echo "	<h5>&nbsp;&nbsp;&nbsp;Fill out the following fields to create a new user: </h5>";
		echo "	<h6><font color='red'>&nbsp;&nbsp;&nbsp;&nbsp;Please fill out all required fields marked with a *.</font></h6>";
		echo "	<br/>";
		
		
	echo "	<form class='ml-3 mr-sm-2' action='Form Handlers/createUserHandler.php' method='post'>
		<div class='form-row mb-2 mr-sm-2'>
	  
			<div class='form-group col-md-4'>
				<label for='username'>Username*</label>
				<input name='username' type='name' class='form-control' id='username' placeholder='Username' required>
			</div>
			
			<div class='form-group col-md-6'>
				<label for='password'>Password*</label>
				<input name='password' type='name' id='password' class='form-control' placeholder='Username' required/>
			</div>
			
		</div>
	  <button type='submit' class='btn btn-info mb-4'>Create</button>
	  </form>";
		
		
		
		?>
		
	  
		
   </body>
</html>