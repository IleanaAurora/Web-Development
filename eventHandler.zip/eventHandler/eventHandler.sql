create database eventHandler;
Use eventHandler;

CREATE TABLE Venue (
VenueID 	INT NOT NULL auto_increment,
VName	VARCHAR(80) NOT NULL,
Capacity	int(7) NOT NULL,
RentalCost 	int(7) NOT NULL,
VDescription VARCHAR(400),
AvailableEquip 	VARCHAR(300),
VImages	VARCHAR(200),
Address VARCHAR(70) NOT NULL,
VPhone	VARCHAR(20) NOT NULL,
VEmail	VARCHAR(40),
CONSTRAINT Venue PRIMARY KEY (VenueID));

CREATE TABLE Performer (
PerformerID 	INT NOT NULL auto_increment,
PName	VARCHAR(80) NOT NULL,
PDescription	VARCHAR(300),
Fees 	int(7) NOT NULL,
ExpAudienceSize 	int(7),
PImages	VARCHAR(200),
Videos LONGBLOB,
PPhone	VARCHAR(20) NOT NULL,
PEmail	VARCHAR(40),
CONSTRAINT PerformerID PRIMARY KEY (PerformerID));

CREATE TABLE EType (
ETypeID INT NOT NULL auto_increment,
EType VARCHAR(40) NOT NULL,
SuggestedStartTime TIME NOT NULL,
CONSTRAINT ETypeID PRIMARY KEY (ETypeID));

CREATE TABLE PromoMaterials (
PromoMaterialID INT NOT NULL auto_increment,
MType VARCHAR(40) NOT NULL,
Location VARCHAR(200),
CONSTRAINT PromoMaterialID PRIMARY KEY (PromoMaterialID));

CREATE TABLE Events (
EventID 	INT NOT NULL auto_increment,
EName	VARCHAR(80) NOT NULL,
ETypeID 	VARCHAR(40) NOT NULL,
ExpAttendeesNo	int(10),
ActAttendeesNo	int(10) NOT NULL,
StartDate	DATETIME NOT NULL,
EndDate		DATETIME NOT NULL,
Duration	TIME,
SpecialReq VARCHAR(300),
TicPrice	DECIMAL UNSIGNED NOT NULL,
Profit		DECIMAL NOT NULL,
PromoMaterialID VARCHAR(80),
ReportPDFLoc	VARCHAR(300),
ClientID	int(5) NOT NULL,
VenueID		int(5) NOT NULL,
PerformerID	int(5),
CONSTRAINT Events_EventID_pk PRIMARY KEY (EventID),
CONSTRAINT Events_EType_fk FOREIGN KEY (ETypeID) REFERENCES EType (ETypeID),
CONSTRAINT Events_ClientID_fk FOREIGN KEY (ClientID) REFERENCES EType (ClientID),
CONSTRAINT Events_VenueID_fk FOREIGN KEY (VenueID) REFERENCES Venue  (VenueID),
CONSTRAINT Events_PerformerID_fk FOREIGN KEY (PerformerID) REFERENCES Performer (PerformerID));

CREATE TABLE Clients (
ClientID INT NOT NULL auto_increment,
CName VARCHAR(80) NOT NULL,
CPhone	VARCHAR(20) NOT NULL,
CEmail	VARCHAR(40) NOT NULL,
CONSTRAINT ClientID PRIMARY KEY (ClientID));

CREATE TABLE Users (
UserID INT NOT NULL auto_increment,
AccountType int(1) NOT NULL,
Username	VARCHAR(30) NOT NULL,
Password	VARCHAR(150) NOT NULL,
CONSTRAINT UserID PRIMARY KEY (UserID));

INSERT INTO Users (AccountType,Username,Password) VALUES (0,"admin","D033E22AE348AEB5660FC2140AEC35850C4DA997");
INSERT INTO Users (AccountType,Username,Password) VALUES (1,"user","12DEA96FEC20593566AB75692C9949596833ADC9");

INSERT INTO Venue (VName,Capacity,RentalCost,VDescription,AvailableEquip,VImages,Address,VPhone,VEmail) VALUES ("The Atrium at Brooklyn Botanical Garden",125,6000,"A lovely living roof of native grasses and wildflowers, floor-to-ceiling glass walls that look out onto the Garden's Cherry Esplanade, and an outdoor terrace. The Atrium offers an intimate and luxurious space as well as catering for weddings and other events.","mood lighting, A/V equipment","Images/Venues/The_Atrium/","990 Washington Ave, Brooklyn, NY 11225","(718) 307-7137","cjohnston@patinagroup.com");
INSERT INTO Venue (VName,Capacity,RentalCost,VDescription,AvailableEquip,VImages,Address,VPhone,VEmail) VALUES ("The Grand Ballroom at the Plaza Hotel",500,12000,"Culinary mastery and personal service that has defined The Plaza and New York City meetings, weddings, conferences, events, and other festivities that help redefine luxury.","DJ, special lighting, sound effects, spotlights, stage","Images/Venues/The_Grand_Ballroom/","Fifth Avenue at Central Park South, New York, NY 10019","(212) 759-3000","plazareservation@fairmont.com");
INSERT INTO Venue (VName,Capacity,RentalCost,VDescription,AvailableEquip,VImages,Address,VPhone,VEmail) VALUES ("Yankee Stadium",500,20000,"Historic Yankee Stadium has numerous event spaces perfect for your corporate event, fundraiser, conference, holiday party, wedding, birthday, graduation, etc. Book your next event with us and make it one to remember!","A/V equipment, break out rooms, business center, outdoor space, stage","Images/Venues/Yankee_Stadium/","1 E 161st St, Bronx, NY 10451, USA, New York, NY","(646) 977-8400","events@yankees.com");
INSERT INTO Venue (VName,Capacity,RentalCost,VDescription,AvailableEquip,VImages,Address,VPhone,VEmail) VALUES ("Citi Field",6000,8000,"Citi Field has more than 200,000 square feet of hospitality space, which can accommodate corporate meetings, receptions, private parties, trade shows.","Jumbotron, loudspeaker, stadium seating, stage, A/V equipment","Images/Venues/Citi_Field/","41 Seaver Way, Queens, NY 11368","(718) 507-8499","gexperience@nymets.com");
INSERT INTO Venue (VName,Capacity,RentalCost,VDescription,AvailableEquip,VImages,Address,VPhone,VEmail) VALUES ("MetLife Stadium",350,7500,"From an intimate dark wooded lounge to a bustling and colorful field-side club, our state-of-the-art event spaces are sure to provide a unique and memorable experience.","stage, TV's, banquet & buffet station","Images/Venues/MetLife_Stadium/","One MetLife Stadium Drive, East Rutherford, NJ 07073","(201) 559-1710","specialevents@metlifestadium.com");
INSERT INTO Venue (VName,Capacity,RentalCost,VDescription,AvailableEquip,VImages,Address,VPhone,VEmail) VALUES ("Madison Square Garden",19500,50000,"If your special event requires a space unparalleled in scale, history, excitement and energy, Madison Square Garden, home to New York's favorite sports teams, is your venue.","stage, spotlights, mood lighting, A/V equipment, red carpet, dressing rooms, green rooms","Images/Venues/MSG/","4 Pennsylvania Plaza, New York, NY 10001","1 (212) 465-6106","specialevents@msg.com");
INSERT INTO Venue (VName,Capacity,RentalCost,VDescription,AvailableEquip,VImages,Address,VPhone,VEmail) VALUES ("PlayStation Theater",21000,15000,"The Theater is 45,000 square feet and features two VIP balconies, in-house lighting, and an in-house sound system by JBL. PlayStation Theater is perfect for large or small scale events including concerts, cocktail receptions, galas, live broadcasts, awards shows, lectures, press events, film screenings, fashion shows, upfronts, movie premieres and much more!","stage,in-house lighting, in-house sound system, LED high definition screen, media panels","Images/Venues/PlayStation_Theater/","1515 Broadway at W. 44th St., New York, NY 10036","(332) 207-2528","hvaughan@bowerypresents.com");


INSERT INTO Performer (PName,PDescription,Fees,ExpAudienceSize,PImages,PPhone,PEmail) VALUES ("Michael Jackson","The King of Pop!",6000,5000,"Images/Performers/Michael_Jackson/","(213) 907 5130","mj@sonyentertainment.com");
INSERT INTO Performer (PName,PDescription,Fees,ExpAudienceSize,PImages,PPhone,PEmail) VALUES ("Queen","The Best UK rock band since the Beatles!",6000,4500,"Images/Performers/Queen/","+44 (0) 1483 281995","queentheband@hollywoordrecords.com");
INSERT INTO Performer (PName,PDescription,Fees,ExpAudienceSize,PImages,PPhone,PEmail) VALUES ("Fall Out Boy","One of the biggest names in contemporary alternative rock music!",5000,4000,"Images/Performers/Fall_Out_Boy/","(408) 340-8290","fob@islandrecords.com");
INSERT INTO Performer (PName,PDescription,Fees,ExpAudienceSize,PImages,PPhone,PEmail) VALUES ("Bozo the Clown Magician","The best clown and magician combination you've ever seen!",300,75,"Images/Performers/Bozo_the_Clown_Magician/","(861) 853-5213","bozo@theclownmagician.com");
INSERT INTO Performer (PName,PDescription,Fees,ExpAudienceSize,PImages,PPhone,PEmail) VALUES ("Steve the Animal Wrangler","Handles wildly exotic animals with the greatest care for all to enjoy!",400,120,"Images/Performers/Steve_the_Animal_Wrangler/","(585) 983-4209","steve@animalwrangler.com");
INSERT INTO Performer (PName,PDescription,Fees,ExpAudienceSize,PImages,PPhone,PEmail) VALUES ("MC Clap Yo Handz","A guaranteed good time with music, dancing, and audience participation!",250,140,"Images/Performers/MC_Clap_Yo_Handz/","(644) 456-8421","mcclapyohandz@goodtimestudios.com");
INSERT INTO Performer (PName,PDescription,Fees,ExpAudienceSize,PImages,PPhone,PEmail) VALUES ("DJ Jazzy Jeff","Established DJ,rapper, and record producer!",900,600,"Images/Performers/DJ_Jazzy_Jeff/","(152) 586-6647","djjazzyjeff@bberecords.com");
INSERT INTO Performer (PName,PDescription,Fees,ExpAudienceSize,PImages,PPhone,PEmail) VALUES ("The New York Philharmonic","A classic and renowned symphony orchestra!",1100,2100,"Images/Performers/The_New_York_Philharmonic/","(212) 875-5656","nyphilharmonic@lincolncenter.com");


INSERT INTO EType (EType,SuggestedStartTime) VALUES ("Concert",'19:00:00');
INSERT INTO EType (EType,SuggestedStartTime) VALUES ("Festival/Fair",'12:00:00');
INSERT INTO EType (EType,SuggestedStartTime) VALUES ("Party",'21:00:00');
INSERT INTO EType (EType,SuggestedStartTime) VALUES ("Fundraiser",'10:00:00');
INSERT INTO EType (EType,SuggestedStartTime) VALUES ("Game",'17:00:00');
INSERT INTO EType (EType,SuggestedStartTime) VALUES ("Meeting",'09:00:00');
INSERT INTO EType (EType,SuggestedStartTime) VALUES ("Conference",'08:30:00');
INSERT INTO EType (EType,SuggestedStartTime) VALUES ("Wedding",'16:00:00');


INSERT INTO PromoMaterials (MType) VALUES ("flyers");
INSERT INTO PromoMaterials (MType) VALUES ("giveaways");
INSERT INTO PromoMaterials (MType) VALUES ("emails");
INSERT INTO PromoMaterials (MType) VALUES ("commericals");
INSERT INTO PromoMaterials (MType) VALUES ("signs and banners");
INSERT INTO PromoMaterials (MType) VALUES ("social media");
INSERT INTO PromoMaterials (MType) VALUES ("merchandise");
INSERT INTO PromoMaterials (MType) VALUES ("invitations");


INSERT INTO Clients (CName, CPhone, CEmail) VALUES ("John Smith", "(852) 589-5962","jsmith23@outlook.com");
INSERT INTO Clients (CName, CPhone, CEmail) VALUES ("Jane Doe", "(586) 586-3641","jane.doe@yahoo.com");
INSERT INTO Clients (CName, CPhone, CEmail) VALUES ("Anna Banana", "(612) 635-2632", "abanana35@gmail.com");


INSERT INTO Events (EName,ETypeID,ExpAttendeesNo,ActAttendeesNo,StartDate,EndDate,Duration,SpecialReq,TicPrice,Profit,PromoMaterialID,ClientID,VenueID,PerformerID) VALUES ("Queen takes NY",1,16000,15000,'2019-11-12 20:00:00','2019-11-12  23:00:00','03:00:00',"stage",167.00,2484000,4,1,7,2);
INSERT INTO Events (EName,ETypeID,ExpAttendeesNo,ActAttendeesNo,StartDate,EndDate,Duration,TicPrice,Profit,PromoMaterialID,ClientID,VenueID,PerformerID) VALUES ("MetLife Food Festival",2,600,680,'2019-10-05 11:00:00','2019-10-05  18:00:00','07:00:00',35.00,16000,1,2,5,4);
INSERT INTO Events (EName,ETypeID,ExpAttendeesNo,ActAttendeesNo,StartDate,EndDate,Duration,SpecialReq,TicPrice,Profit,PromoMaterialID,ClientID,VenueID,PerformerID) VALUES ("Steve and Nancy's Wedding Reception",8,125,122,'2019-11-09 16:00:00','2019-11-09  22:00:00','06:00:00',"A/V equipment",55.00,570,8,3,1,6);