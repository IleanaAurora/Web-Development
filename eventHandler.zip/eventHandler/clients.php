<?php
session_start();
include("dbConnection.php");
if (isset($_SESSION['UserID']))
{
	$currUserID = $_SESSION['UserID'];
}
else
{
	echo "<script type='text/javascript'>
			window.location.href = './logout.php';
			</script>";
}
?>

<!DOCTYPE html>
<html>
    <head>
 	<title>Clients</title>
	<?php include './Design/head.html'; 
		ini_set('display_errors', 1);
		ini_set('display_startup_errors', 1);
		error_reporting(E_ALL);
			?>
	<link href="CSS/main.css" rel="stylesheet">
	</head>
   <body>
		<?php include './Design/navBar.html';
		
		echo "	<div class='headings'>";
		
		$qry="SELECT * FROM Clients ORDER BY CName asc";
		$result = $db->query($qry);
		$num_rows = $result->num_rows;
		for ($i=0; $i<$num_rows; $i++)
		{
			$row = $result->fetch_assoc();
			$fullname = explode(" ", $row['CName']);
			if(count($fullname) > 1) {
				$lastname = array_pop($fullname);
				$firstname = implode(" ", $fullname);
			}
			else
			{
				$firstname = $row['CName'];
				$lastname = " ";
			}
			$dispName = $lastname. ", " .$firstname;
			echo "<form class='ml-3 mr-sm-2' action='editPage.php'>";
			echo "	<h1>".$dispName."</h1>";
			echo "			<h2>Contact: </h3>";
			echo "				<h4>".$row['CPhone']."  |  ".$row['CEmail']."</h4>";
			echo "<button type='submit' name='EditClient' class='btn btn-light mb-4'><a href='editPage.php?editClientID=".$row['ClientID']."'>Edit Client</a></button>";
			echo "</form>";
			echo "<form class='ml-3 mr-sm-2 action='GenerateEventReportPDF.php' method='POST'>";
			echo "<input type='hidden' id='name' name='name' value='".$row['ClientID']."'>";
			echo "<button type='submit' name='GenPDF' class='btn btn-light mb-4'><a href='GenerateEventReportPDF.php?passClientID=".$row['ClientID']."'>Generate PDF</a></button>";
			echo "</form>";
			
		echo "</br>";
		echo "</br>";
		echo "</br>";
		echo "</br>";
		}
		echo "	</div>";
		
		
		?>
		
	  
		
   </body>
</html>