-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: eventhandler
-- ------------------------------------------------------
-- Server version	5.7.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clients` (
  `ClientID` int(11) NOT NULL AUTO_INCREMENT,
  `CName` varchar(80) NOT NULL,
  `CPhone` varchar(20) NOT NULL,
  `CEmail` varchar(40) NOT NULL,
  PRIMARY KEY (`ClientID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (1,'John Smith','(852) 589-5962','jsmith23@outlook.com'),(2,'Jane Doe','(586) 586-3641','jane.doe@yahoo.com'),(3,'Anna Banana','(612) 635-2632','abanana35@gmail.com');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etype`
--

DROP TABLE IF EXISTS `etype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etype` (
  `ETypeID` int(11) NOT NULL AUTO_INCREMENT,
  `EType` varchar(40) NOT NULL,
  `SuggestedStartTime` time NOT NULL,
  PRIMARY KEY (`ETypeID`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etype`
--

LOCK TABLES `etype` WRITE;
/*!40000 ALTER TABLE `etype` DISABLE KEYS */;
INSERT INTO `etype` VALUES (1,'Concert','19:00:00'),(2,'Festival/Fair','12:00:00'),(3,'Party','21:00:00'),(4,'Fundraiser','10:00:00'),(5,'Game','17:00:00'),(6,'Meeting','09:00:00'),(7,'Conference','08:30:00'),(8,'Wedding','16:00:00');
/*!40000 ALTER TABLE `etype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `EventID` int(11) NOT NULL AUTO_INCREMENT,
  `EName` varchar(80) NOT NULL,
  `ETypeID` varchar(40) NOT NULL,
  `ExpAttendeesNo` int(10) DEFAULT NULL,
  `ActAttendeesNo` int(10) NOT NULL,
  `StartDate` datetime NOT NULL,
  `EndDate` datetime NOT NULL,
  `Duration` time DEFAULT NULL,
  `SpecialReq` varchar(300) DEFAULT NULL,
  `TicPrice` decimal(10,0) unsigned NOT NULL,
  `Profit` decimal(10,0) NOT NULL,
  `PromoMaterialID` varchar(80) DEFAULT NULL,
  `ReportPDFLoc` varchar(300) DEFAULT NULL,
  `ClientID` int(5) NOT NULL,
  `VenueID` int(5) NOT NULL,
  `PerformerID` int(5) DEFAULT NULL,
  PRIMARY KEY (`EventID`),
  KEY `Events_EType_fk` (`ETypeID`),
  KEY `Events_ClientID_fk` (`ClientID`),
  KEY `Events_VenueID_fk` (`VenueID`),
  KEY `Events_PerformerID_fk` (`PerformerID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (1,'Queen takes NY','1',16000,15000,'2019-11-12 20:00:00','2019-11-12 23:00:00','03:00:00','stage',167,2484000,'4',NULL,1,7,2),(2,'MetLife Food Festival','2',600,680,'2019-10-05 11:00:00','2019-10-05 18:00:00','07:00:00',NULL,35,16000,'1',NULL,2,5,4),(3,'Steve and Nancy\'s Wedding Reception','8',125,122,'2019-11-09 16:00:00','2019-11-09 22:00:00','06:00:00','A/V equipment',55,570,'8',NULL,3,1,6);
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `performer`
--

DROP TABLE IF EXISTS `performer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `performer` (
  `PerformerID` int(11) NOT NULL AUTO_INCREMENT,
  `PName` varchar(80) NOT NULL,
  `PDescription` varchar(300) DEFAULT NULL,
  `Fees` int(7) NOT NULL,
  `ExpAudienceSize` int(7) DEFAULT NULL,
  `PImages` varchar(200) DEFAULT NULL,
  `Videos` longblob,
  `PPhone` varchar(20) NOT NULL,
  `PEmail` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`PerformerID`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `performer`
--

LOCK TABLES `performer` WRITE;
/*!40000 ALTER TABLE `performer` DISABLE KEYS */;
INSERT INTO `performer` VALUES (1,'Michael Jackson','The King of Pop!',6000,5000,'Images/Performers/Michael_Jackson/',NULL,'(213) 907 5130','mj@sonyentertainment.com'),(2,'Queen','The Best UK rock band since the Beatles!',6000,4500,'Images/Performers/Queen/',NULL,'+44 (0) 1483 281995','queentheband@hollywoordrecords.com'),(3,'Fall Out Boy','One of the biggest names in contemporary alternative rock music!',5000,4000,'Images/Performers/Fall_Out_Boy/',NULL,'(408) 340-8290','fob@islandrecords.com'),(4,'Bozo the Clown Magician','The best clown and magician combination you\'ve ever seen!',300,75,'Images/Performers/Bozo_the_Clown_Magician/',NULL,'(861) 853-5213','bozo@theclownmagician.com'),(5,'Steve the Animal Wrangler','Handles wildly exotic animals with the greatest care for all to enjoy!',400,120,'Images/Performers/Steve_the_Animal_Wrangler/',NULL,'(585) 983-4209','steve@animalwrangler.com'),(6,'MC Clap Yo Handz','A guaranteed good time with music, dancing, and audience participation!',250,140,'Images/Performers/MC_Clap_Yo_Handz/',NULL,'(644) 456-8421','mcclapyohandz@goodtimestudios.com'),(7,'DJ Jazzy Jeff','Established DJ,rapper, and record producer!',900,600,'Images/Performers/DJ_Jazzy_Jeff/',NULL,'(152) 586-6647','djjazzyjeff@bberecords.com'),(8,'The New York Philharmonic','A classic and renowned symphony orchestra!',1100,2100,'Images/Performers/The_New_York_Philharmonic/',NULL,'(212) 875-5656','nyphilharmonic@lincolncenter.com');
/*!40000 ALTER TABLE `performer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promomaterials`
--

DROP TABLE IF EXISTS `promomaterials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promomaterials` (
  `PromoMaterialID` int(11) NOT NULL AUTO_INCREMENT,
  `MType` varchar(40) NOT NULL,
  `Location` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`PromoMaterialID`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promomaterials`
--

LOCK TABLES `promomaterials` WRITE;
/*!40000 ALTER TABLE `promomaterials` DISABLE KEYS */;
INSERT INTO `promomaterials` VALUES (1,'flyers',NULL),(2,'giveaways',NULL),(3,'emails',NULL),(4,'commericals',NULL),(5,'signs and banners',NULL),(6,'social media',NULL),(7,'merchandise',NULL),(8,'invitations',NULL);
/*!40000 ALTER TABLE `promomaterials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `UserID` int(11) NOT NULL AUTO_INCREMENT,
  `AccountType` int(1) DEFAULT NULL,
  `Username` varchar(30) NOT NULL,
  `Password` varchar(150) NOT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,0,'admin','D033E22AE348AEB5660FC2140AEC35850C4DA997'),(2,1,'user','12DEA96FEC20593566AB75692C9949596833ADC9');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `venue`
--

DROP TABLE IF EXISTS `venue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `venue` (
  `VenueID` int(11) NOT NULL AUTO_INCREMENT,
  `VName` varchar(80) NOT NULL,
  `Capacity` int(7) NOT NULL,
  `RentalCost` int(7) NOT NULL,
  `VDescription` varchar(400) DEFAULT NULL,
  `AvailableEquip` varchar(300) DEFAULT NULL,
  `VImages` varchar(200) DEFAULT NULL,
  `Address` varchar(70) NOT NULL,
  `VPhone` varchar(20) NOT NULL,
  `VEmail` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`VenueID`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venue`
--

LOCK TABLES `venue` WRITE;
/*!40000 ALTER TABLE `venue` DISABLE KEYS */;
INSERT INTO `venue` VALUES (1,'The Atrium at Brooklyn Botanical Garden',125,6000,'A lovely living roof of native grasses and wildflowers, floor-to-ceiling glass walls that look out onto the Garden\'s Cherry Esplanade, and an outdoor terrace. The Atrium offers an intimate and luxurious space as well as catering for weddings and other events.','mood lighting, A/V equipment','Images/Venues/The_Atrium/','990 Washington Ave, Brooklyn, NY 11225','(718) 307-7137','cjohnston@patinagroup.com'),(2,'The Grand Ballroom at the Plaza Hotel',500,12000,'Culinary mastery and personal service that has defined The Plaza and New York City meetings, weddings, conferences, events, and other festivities that help redefine luxury.','DJ, special lighting, sound effects, spotlights, stage','Images/Venues/The_Grand_Ballroom/','Fifth Avenue at Central Park South, New York, NY 10019','(212) 759-3000','plazareservation@fairmont.com'),(3,'Yankee Stadium',500,20000,'Historic Yankee Stadium has numerous event spaces perfect for your corporate event, fundraiser, conference, holiday party, wedding, birthday, graduation, etc. Book your next event with us and make it one to remember!','A/V equipment, break out rooms, business center, outdoor space, stage','Images/Venues/Yankee_Stadium/','1 E 161st St, Bronx, NY 10451, USA, New York, NY','(646) 977-8400','events@yankees.com'),(4,'Citi Field',6000,8000,'Citi Field has more than 200,000 square feet of hospitality space, which can accommodate corporate meetings, receptions, private parties, trade shows.','Jumbotron, loudspeaker, stadium seating, stage, A/V equipment','Images/Venues/Citi_Field/','41 Seaver Way, Queens, NY 11368','(718) 507-8499','gexperience@nymets.com'),(5,'MetLife Stadium',350,7500,'From an intimate dark wooded lounge to a bustling and colorful field-side club, our state-of-the-art event spaces are sure to provide a unique and memorable experience.','stage, TV\'s, banquet & buffet station','Images/Venues/MetLife_Stadium/','One MetLife Stadium Drive, East Rutherford, NJ 07073','(201) 559-1710','specialevents@metlifestadium.com'),(6,'Madison Square Garden',19500,50000,'If your special event requires a space unparalleled in scale, history, excitement and energy, Madison Square Garden, home to New York\'s favorite sports teams, is your venue.','stage, spotlights, mood lighting, A/V equipment, red carpet, dressing rooms, green rooms','Images/Venues/MSG/','4 Pennsylvania Plaza, New York, NY 10001','1 (212) 465-6106','specialevents@msg.com'),(7,'PlayStation Theater',21000,15000,'The Theater is 45,000 square feet and features two VIP balconies, in-house lighting, and an in-house sound system by JBL. PlayStation Theater is perfect for large or small scale events including concerts, cocktail receptions, galas, live broadcasts, awards shows, lectures, press events, film screenings, fashion shows, upfronts, movie premieres and much more!','stage,in-house lighting, in-house sound system, LED high definition screen, media panels','Images/Venues/PlayStation_Theater/','1515 Broadway at W. 44th St., New York, NY 10036','(332) 207-2528','hvaughan@bowerypresents.com');
/*!40000 ALTER TABLE `venue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'eventhandler'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-07  0:43:36
