<!DOCTYPE html>
<?php
session_start(); 
if (isset($_SESSION['UserID']))
{
	$currUserID = $_SESSION['UserID'];
}
else
{
	echo "<script type='text/javascript'>
			window.location.href = './logout.php';
			</script>";
}
?>
<html>
    <head>
		<title>Event Handler</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="CSS/main.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>	
	</head>
   <body>
		<div id="jumbotron" class="jumbotron text-center">
			<button id="LougoutButton" type="button" name="Logout" onclick="window.location.href='logout.php';" style="float:right;" class='btn btn-light mb-4'><b>Logout</b></button>
			<h1 class="font-weight-bold text-center">Event Handler Administrative Access</h1>
			<h3>Manage your Users&#8482;</h3> 
		</div>
		
		
		<div id="navBar" class="nav-scroller py-1 mb-2">
			<nav class="nav d-flex justify-content-between">		  
			  <a class="p-2 text-muted" href="createUser.php">Create New User</a>
			  <a class="p-2 text-muted" href="deleteUser.php">Delete User</a>
			  <a class="p-2 text-muted" href="changePassword.php">Change User Password</a>
			</nav>
		</div>		
		
		
	  
		
   </body>
</html>