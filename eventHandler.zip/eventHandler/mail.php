<?php
	session_start();
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);
	
	include("dbConnection.php");
	
		if (isset($_SESSION['UserID']))
	{
		$currUserID = $_SESSION['UserID'];
	}
	else
	{
		echo "<script type='text/javascript'>
				window.location.href = './logout.php';
				</script>";
	}
	
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;

	require './PHPMailer/PHPMailer/src/Exception.php';
	require './PHPMailer/PHPMailer/src/PHPMailer.php';
	require './PHPMailer/PHPMailer/src/SMTP.php';
	require('./FPDF/fpdf.php'); 
	
	
	
	
class PDF extends FPDF
{
	var $widths;
	var $aligns;
	
	
	// DEFAULT METHODS
	function SetWidths($w)
	{
		//Set the array of column widths
		$this->widths=$w;
	}

	function SetAligns($a)
	{
		//Set the array of column alignments
		$this->aligns=$a;
	}

	function Row($data, $r, $g, $b)
	{			
		//Calculate the height of the row
		$nb=0;
		for($i=0;$i<count($data);$i++)
			$nb=max($nb, $this->NbLines($this->widths[$i], $data[$i]));
		$h=5*$nb;
		//Issue a page break first if needed
		$this->CheckPageBreak($h);
		//Draw the cells of the row
		for($i=0;$i<count($data);$i++)
		{
			$w=$this->widths[$i];
			$a=isset($this->aligns[$i]) ? $this->aligns[$i] : 'L';
			//Save the current position
			$x=$this->GetX();
			$y=$this->GetY();
			//Draw the border
			$this->SetFillColor($r, $g, $b);
			$this->SetDrawColor(0,0,0);
			$this->SetLineWidth(.05);
			$this->Rect($x, $y, $w-.01, $h+1, 'DF');
				
			//	$this->SetFont('','B');
			//Print the text
			$this->MultiCell($w, 5, $data[$i], "LTR", $a, true);
			//Put the position to the right of the cell
			$this->SetXY($x+$w, $y);
		}
		//Go to the next line
		$this->Ln($h);
	}
	
	function CheckPageBreak($h)
	{
		//If the height h would cause an overflow, add a new page immediately
		if($this->GetY()+$h>$this->PageBreakTrigger)
			$this->AddPage($this->CurOrientation);
	}

	function NbLines($w, $txt)
	{
		//Computes the number of lines a MultiCell of width w will take
		$cw=&$this->CurrentFont['cw'];
		if($w==0)
			$w=$this->w-$this->rMargin-$this->x;
		$wmax=($w-2*$this->cMargin)*1000/$this->FontSize;
		$s=str_replace("\r", '', $txt);
		$nb=strlen($s);
		if($nb>0 and $s[$nb-1]=="\n")
			$nb--;
		$sep=-1;
		$i=0;
		$j=0;
		$l=0;
		$nl=1;
		while($i<$nb)
		{
			$c=$s[$i];
			if($c=="\n")
			{
				$i++;
				$sep=-1;
				$j=$i;
				$l=0;
				$nl++;
				continue;
			}
			if($c==' ')
				$sep=$i;
			$l+=$cw[$c];
			if($l>$wmax)
			{
				if($sep==-1)
				{
					if($i==$j)
						$i++;
				}
				else
					$i=$sep+1;
				$sep=-1;
				$j=$i;
				$l=0;
				$nl++;
			}
			else
				$i++;
		}
		return $nl;
	}


	// HEADER and FOOTER - automatically executed
	function Header()
	{
		// Logo
		$this->Image('Images/Backgrounds/logo.jpg',10,6,25);
		// Arial bold 18
		$this->SetFont('Arial','B',18);
		// Draw an empty cell to move the next text in the right corner
		$this->Cell(80);
		// Report title
		$this->Cell(160,10,'Event Reminder Report',0,0,'C');
		// Line break
		$this->Ln(20);
	}


	function Footer()
	{
		$this->SetY(-15);
		$this->SetFont('Arial','I',8);
		$this->Cell(0, 10, 'Page '.$this->PageNo().' of {nb}', 0, 0, 'L');
		$this->Cell(0, 10, date('m/d/Y H:i:s'), 0, 0, 'R');		    
	}



	// ---------- My Custom Tables ---------
	function ClientTable($header, $data, $widths)
	{
		// Color R/G/B parameters between 0 and 255 each
		$this->SetFillColor(9, 63, 111);
		$this->SetTextColor(255); // If only one argument, it's assumed to be gray scale level. Otherwise use 3 parameters for red/green/blue values (0-255 each)
		$this->SetDrawColor(0,0,0);
		$this->SetLineWidth(.1); 
		$this->SetFont('','B');// '' means "keep current font family". 'B' is "bold"

		$w = $widths;
		for($i=0;$i<count($header);$i++)
			$this->Cell($widths[$i],7,$header[$i],1,0,'C',true);
		$this->Ln();

		$this->SetFillColor(225,234,224);
		$this->SetTextColor(0);
		$this->SetDrawColor(0,0,0);
		$this->SetFont('Arial', '', 9);
		$this->SetWidths($widths);
		
		foreach($data as $row)
		{
			$this->Row(array($row[0], $row[1], $row[2], $row[3]), 255, 255, 255);				  
		}

	}
	
	function EventsTable($header, $data, $widths)
	{
		// Color R/G/B parameters between 0 and 255 each
		$this->SetFillColor(185, 28, 43);
		$this->SetTextColor(255); // If only one argument, it's assumed to be gray scale level. Otherwise use 3 parameters for red/green/blue values (0-255 each)
		$this->SetDrawColor(0,0,0);
		$this->SetLineWidth(.1); 
		$this->SetFont('','B');// '' means "keep current font family". 'B' is "bold"

		$w = $widths;
		for($i=0;$i<count($header);$i++)
			$this->Cell($widths[$i],7,$header[$i],1,0,'C',true);
		$this->Ln();

		$this->SetFillColor(225,234,224);
		$this->SetTextColor(0);
		$this->SetDrawColor(0,0,0);
		$this->SetFont('Arial', '', 9);
		$this->SetWidths($widths);
		
		foreach($data as $row)
		{
			$this->Row(array($row[0], $row[1], $row[2], $row[3], $row[4], $row[5], $row[6]), 255, 255, 255);				  
		}

	}	

		function PerformerTable($header, $data, $widths)
	{
		// Color R/G/B parameters between 0 and 255 each
		$this->SetFillColor(185, 28, 43);
		$this->SetTextColor(255); // If only one argument, it's assumed to be gray scale level. Otherwise use 3 parameters for red/green/blue values (0-255 each)
		$this->SetDrawColor(0,0,0);
		$this->SetLineWidth(.1); 
		$this->SetFont('','B');// '' means "keep current font family". 'B' is "bold"

		$w = $widths;
		for($i=0;$i<count($header);$i++)
			$this->Cell($widths[$i],7,$header[$i],1,0,'C',true);
		$this->Ln();

		$this->SetFillColor(225,234,224);
		$this->SetTextColor(0);
		$this->SetDrawColor(0,0,0);
		$this->SetFont('Arial', '', 9);
		$this->SetWidths($widths);
		
		foreach($data as $row)
		{
			$this->Row(array($row[0], $row[1], $row[2]), 255, 255, 255);				  
		}

	}	
}
	
	
	
	// Current date and time
	$currDate = date("Y-m-d");
	
	$query = "SELECT EventID,StartDate FROM Events";
	$result = $db->query($query);	
	$numrows = $result->num_rows;	
	
	
	$eventIDArray=array();
	for ($i=0; $i<$numrows ; $i++)
	{
		$row = $result->fetch_assoc();
		$eventID = $row['EventID'];
		$StartDate = $row['StartDate'];
		
		$StartDate = explode(' ',$StartDate);
		$eventDate = $StartDate[0];
		// Convert datetime to Unix timestamp
		$date = strtotime($eventDate);
		// Subtract a week from eventDate
		$prevWeekDate = $date - (168 * 60* 60);
		$prevWeekDate = date('Y-m-d',$prevWeekDate);
		// Subtract a day from eventDate
		$dayBeforeDate = $date - (24 * 60* 60);
		$dayBeforeDate = date('Y-m-d',$dayBeforeDate);
		
		if(($prevWeekDate == $currDate) || ($dayBeforeDate == $currDate) || ($eventDate == $currDate))
			array_push($eventIDArray, array($eventID));
	}
	
	
	
	
	if(!empty($eventIDArray))
	{
		$now = new DateTime(null, new DateTimeZone('America/New_York'));
		$date = $now->format('m/d/Y');
		
		$query = "SELECT * FROM Events,Clients,Venue,Performer,Etype,PromoMaterials WHERE Clients.ClientID=Events.ClientID and Venue.VenueID=Events.VenueID and Performer.PerformerID=Events.PerformerID and EType.ETypeID=Events.ETypeID and PromoMaterials.PromoMaterialID=Events.PromoMaterialID and Events.EventID='$eventID'";
		$result = $db->query($query);	
		$numrows = $result->num_rows;	

		$eventsArray=array();
		$venueArray1=array();
		$venueArray2=array();
		$performerArray1=array();
		$performerArray2=array();
		for ($i=0; $i<$numrows ; $i++)
		{
			$row = $result->fetch_assoc();
			$eventName = $row['EName'];
			$eventName = str_replace('&#39;','\'', $eventName);
			$clientName = $row['CName'];
			$CPhone = $row['CPhone'];
			$CEmail = $row['CEmail'];
			$venueName = $row['VName'];
			$VDescription = $row['VDescription'];
			$venueAddr = $row['Address'];
			$capacity = $row['Capacity'];
			$venueCost = $row['RentalCost'];
			$VPhone = $row['VPhone'];
			$VEmail = $row['VEmail'];
			$AvailableEquip = $row['AvailableEquip'];
			$actAttendance = $row['ActAttendeesNo'];
			$ticketCost = $row['TicPrice'];
			$performer = $row['PName'];
			$PDescription = $row['PDescription'];
			$PPhone = $row['PPhone'];
			$PEmail = $row['PEmail'];
			$performerCost = $row['Fees'];
			$eventDate = $row['StartDate'];
			$eventDate = date( 'm/d/Y g:i A', strtotime($eventDate));
			$profit = $row['Profit'];
			$eventType = $row['EType'];
			$duration = $row['Duration'];
			$specialReq = $row['SpecialReq'];
			$ticPrice = $row['TicPrice'];
			$promo = $row['MType'];
			
					
			if ($profit > 2000)
				$profit -= $profit*.15; // 15% is our event organizer cost
			else
				$profit -= 200; // If less than $2000, our flat fee is $200
			
			array_push($eventsArray, array($eventDate, $duration, $eventName, $eventType, $ticketCost, $promo, $actAttendance));
			array_push($venueArray1, array($venueName, $VDescription, $capacity, $venueCost));
			array_push($venueArray2, array($venueAddr, $VPhone, $VEmail, $AvailableEquip));
			array_push($performerArray1, array($performer, $PDescription, $performerCost));
			array_push($performerArray2, array($PPhone, $PEmail, $specialReq));
		}	
		
		
		
		$pdf = new PDF();
		$header = array('Client', 'Phone No.', 'Email', 'Date');
		$data = array();
		$data[0]=array($clientName, $CPhone, $CEmail, $date);
		$widths = array(40, 30, 90, 30);

		// Set alias for number of pages. Will be calculated and substituted at the end.
		$pdf->AliasNbPages();	
		
		// Create new page	(Header() and Footer() functions executed automatically
		$pdf->AddPage();
		
		// Blank lines
		$pdf->Ln(5);
		
		// Default font and draw color
		$pdf->SetFont('Arial', '', 9);
		$pdf->SetDrawColor(0,0,0);
		
		// Draw the client description table.
		$pdf->ClientTable($header, $data, $widths);
		
		// Now prepare and draw the events table.
		$eventsHeader = array('Event Date', 'Duration', 'Event Name', 'Event Type', 'Ticket Cost', 
						'Promotional Materials', 'Attendee No.');
		$eventWidths = array(18, 20, 40, 30, 20, 40, 22);
		$pdf->Ln(5);
		$venueHeader1 = array('Venue', 'Description', 'Capacity', 'Rental Cost');
		$venueHeader2 = array('Address', 'Phone No.', 'Email', 'Available Equipment');
		$PerformerHeader1 = array('Performer', 'Description', 'Fees');
		$PerformerHeader2 = array('Phone No.', 'Email', 'Special Requirements');
		$venueWidths1 = array(34, 120, 18, 18);
		$venueWidths2 = array(50, 30, 55, 55);
		$PerformerWidths1 = array(40, 132, 18);
		$PerformerWidths2 = array(30, 60, 100);
		$pdf->Ln(5);
		$pdf->EventsTable($eventsHeader, $eventsArray, $eventWidths);
		$pdf->Ln(5);
		$pdf->ClientTable($venueHeader1, $venueArray1, $venueWidths1);
		$pdf->ClientTable($venueHeader2, $venueArray2, $venueWidths2);
		$pdf->Ln(5);
		$pdf->PerformerTable($PerformerHeader1, $performerArray1, $PerformerWidths1);
		$pdf->PerformerTable($PerformerHeader2, $performerArray2, $PerformerWidths2);				
				
				
				

		$mail = new PHPMailer;
		$mail->isSMTP();                                // Set mailer to use SMTP                     // SMTP server
		$mail->Host = 'tls://smtp.gmail.com:587';
		$mail->SMTPAuth = true;                         // Enable SMTP authentication
		$mail->Username = 'eventHandler97@gmail.com';                 // SMTP username
		//$mail->Password = 'Iona@209';                 // SMTP password
		$mail->Password = 'atvtjwsxyfqdiwvh';                 // SMTP Google generated app password, grants complete access to account w two-step verification
		$mail->SMTPSecure = 'tls';                      // Enable TLS encryption, `ssl` also accepted
		$mail->SMTPAutoTLS = false;
		//$mail->SMTPDebug = 2;
		$mail->From = 'eventHandler97@gmail.com';
		$mail->Port = 587;                              // SMTP Port
		$mail->FromName  = 'Event Handler Reminders';

		$mail->Subject   = "REMINDER: Your upcoming event report is ready.";
		$mail->Body      = "Please review the report details for the following upcoming event...";
		/*email the client, performer, and venue involved in the event
		$mail->AddAddress($CEmail);
		$mail->AddAddress($PEmail);
		$mail->AddAddress($VEmail);*/
		$destinationEmail = 'eventHandler97@gmail.com';
		$mail->AddAddress($destinationEmail);
		$mail->addStringAttachment($pdf->Output("S",'EventReminderReport.pdf'), 'EventReminderReport.pdf', $encoding = 'base64', $type = 'application/pdf');
		
		if(!$mail->Send()) {
		  //echo 'Message was not sent.';
		  //echo 'Mailer error: ' . $mail->ErrorInfo;
		} else {
		  //echo 'Message has been sent.';
		}
	
	
	}
	else
	{
		//echo 'No email reminders to be sent.';
	}
	
	$db->close();
?>