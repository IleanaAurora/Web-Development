<!DOCTYPE html>
<?php
session_start();
if (isset($_SESSION['UserID']))
{
	$currUserID = $_SESSION['UserID'];
}
else
{
	echo "<script type='text/javascript'>window.location.href = './logout.php';</script>";
}
?>
<html>
    <head>
		<title>Event Handler</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="CSS/main.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>	
	</head>
   <body>
		<div id="jumbotron" class="jumbotron text-center">
			<button id="LougoutButton" type="button" name="Logout" onclick="window.location.href='logout.php';" style="float:right;" class='btn btn-light mb-4'><b>Logout</b></button>
			<h1 class="font-weight-bold text-center">Event Handler</h1>
			<h3>The Ultimate Entertainment Event Organizing Tool	&#8482;</h3> 
		</div>
		
		
		<div id="navBar" class="nav-scroller py-1 mb-2">
			<nav class="nav d-flex justify-content-between">
			  <a class="p-2 text-muted" href="homepage.php">Home</a>
			  <div class="dropdown">
				  <button class="btn dropdown-toggle p-2 text-muted" type="button" data-toggle="dropdown">Create
				  <span class="caret"></span></button>
				  <ul class="dropdown-menu">
					<li><a class="dropdown-createClient" href="createClient.php">New Client</a></li>
					<li><a class="dropdown-createEType" href="createEType.php">New Event Type</a></li>
					<li><a class="dropdown-createPerformer" href="createPerformer.php">New Performer</a></li>
					<li><a class="dropdown-createVenue" href="createVenue.php">New Venue</a></li>
				  </ul>
				</div>			  
			  <a class="p-2 text-muted" href="scheduling.php">Schedule an Event</a>
			  <a class="p-2 text-muted" href="clients.php">Clients</a>
			  <a class="p-2 text-muted" href="performers.php">Performers</a>
			  <a class="p-2 text-muted" href="venues.php">Venues</a>
			  <a class="p-2 text-muted" href="pastEvents.php">Past Events</a>
			  <a class="p-2 text-muted" href="upcomingEvents.php">Upcoming Events</a>
			</nav>
		</div>		
		
		<div id="id" class="carousel slide" data-ride="carousel">
			<ul class="carousel-indicators">
				<li data-target="#id" data-slide-to="0" class="active"></li>
				<li data-target="#id" data-slide-to="1"></li>
				<li data-target="#id" data-slide-to="2"></li>
				<li data-target="#id" data-slide-to="3"></li>
				<li data-target="#id" data-slide-to="4"></li>
				<li data-target="#id" data-slide-to="5"></li>
			</ul>
			
			<div class="carousel-inner">
				<div class="carousel-item active">
					<img src="./Images/Homepage/1.jpg" class="img-fluid rounded mx-auto d-block">
				</div>
				<div class="carousel-item">
					<img src="./Images/Homepage/2.jpg" class="img-fluid rounded mx-auto d-block">
				</div>
				<div class="carousel-item">
					<img src="./Images/Homepage/3.jpg" class="img-fluid rounded mx-auto d-block">
				</div>
				<div class="carousel-item">
					<img src="./Images/Homepage/4.jpg" class="img-fluid rounded mx-auto d-block">
				</div>
				<div class="carousel-item">
					<img src="./Images/Homepage/5.jpg" class="img-fluid rounded mx-auto d-block">
				</div>
				<div class="carousel-item">
					<img src="./Images/Homepage/6.jpg" class="img-fluid rounded mx-auto d-block">
				</div>
			</div>
		</div>
		
	  
		
   </body>
</html>