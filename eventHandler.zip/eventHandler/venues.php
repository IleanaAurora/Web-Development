<?php
session_start();
include("dbConnection.php");
	if (isset($_SESSION['UserID']))
	{
		$currUserID = $_SESSION['UserID'];
	}
	else
	{
		echo "<script type='text/javascript'>
				window.location.href = './logout.php';
				</script>";
	}
?>

<!DOCTYPE html>
<html>
    <head>
 	<title>Venues</title>
	<?php include './Design/head.html';
		ini_set('display_errors', 1);
		ini_set('display_startup_errors', 1);
		error_reporting(E_ALL);
		?>
	<link href="CSS/main.css" rel="stylesheet">
	<style>
	img
{
	position: relative;
	float: left;
	padding: 15px;
}
	</style>
	</head>
   <body>
		<?php include './Design/navBar.html';
				
		echo "	<div class='headings'>";
		
		$qry="SELECT * FROM Venue";
		$result = $db->query($qry);
		$num_rows = $result->num_rows;
		for ($i=0; $i<$num_rows; $i++)
		{
			$row = $result->fetch_assoc();
			echo "<form class='ml-3 mr-sm-2' action='editPage.php'>";
			echo "	<h1>".$row['VName']."</h1>";
			echo "  	<h2>".$row['VDescription']."</h2>";
			$img = $row['VImages']."1.jpg";
			echo "			<img src=$img class='img-fluid rounded mx-auto d-block'>";
			echo "			<h3>Address: </h3>";
			echo "				<h4>".$row['Address']."</h4>";
			echo "			<h3>Contact: </h3>";
			echo "				<h4>".$row['VPhone']."  |  ".$row['VEmail']."</h4>";
			echo "			<h3>Capacity: ".$row['Capacity']."</h3>";
			echo "			<h3>Rental Cost: $".$row['RentalCost']."</h3>";
			echo "			<h3>Available Equipment: ".$row['AvailableEquip']."</h3>";
			echo "<button type='submit' name='EditVenue' class='btn btn-light mb-4'><a href='editPage.php?editVenueID=".$row['VenueID']."'>Edit Venue</a></button>";
			echo "</form>";
			
		echo "</br>";
		echo "</br>";
		echo "</br>";
		echo "</br>";
		echo "</br>";
		echo "</br>";
		echo "</br>";
		echo "</br>";
		echo "</br>";
		echo "</br>";
		echo "</br>";
		}
		echo "	</div>";
		
		
		?>
		
	  
		
   </body>
</html>