<?php
session_start();
include('dbConnection.php');
	if (isset($_SESSION['UserID']))
	{
		$currUserID = $_SESSION['UserID'];
	}
	else
	{
		echo "<script type='text/javascript'>
				window.location.href = './logout.php';
				</script>";
	}
?>

<!DOCTYPE html>
<html>
    <head>
 	<title>Scheduling</title>
	<?php include './Design/head.html';
			ini_set('display_errors', 1);
			ini_set('display_startup_errors', 1);
			error_reporting(E_ALL);
	?>
	<script>
		$(document).ready(function(){
			$('#eventType li').click(function(){
				$('#ETypeDropdown').text($(this).text());
            });
            $('#venue li').click(function(){
				$('#VenueDropdown').text($(this).text());
            });
			$('#performer li').click(function(){
				$('#PerformerDropdown').text($(this).text());
            });
			$('#promo li').click(function(){
				$('#PromoDropdown').text($(this).text());
            });
		});
	</script>
	</head>
   <body>
		<?php include './Design/navBar.html';
		
echo "		<br/>
			<h5>&nbsp;&nbsp;&nbsp;Fill out the following fields to schedule a new event: </h5>
			<h6><font color='red'>&nbsp;&nbsp;&nbsp;&nbsp;Please fill out all required fields marked with a *.</font></h6>
			<br/>
	  
	  <form class='ml-3 mr-sm-2' method='post'>
	  <div class='form-row mb-2 mr-sm-1'>
	  
			<div class='form-group col-md-2'>
				<div class='dropdown'>
				<label for='client'>Client*</label><br/>
					<!--<button class='btn btn-secondary dropdown-toggle' type='button' id='ETypeDropdown' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
					Select
					</button>-->
					<select name='client' class='browser-default custom-select' id='client' aria-labelledby='dropdownMenu2' required>
						<option class='dropdown-item' value=''>Select</option>		";
						
						$qry="SELECT CName, ClientID FROM Clients";
						$result = $db->query($qry);
						$num_rows = $result->num_rows;
						for ($i=0; $i<$num_rows; $i++)
						{
							$row = $result->fetch_assoc();
							$fullname = explode(" ", $row['CName']);
							if(count($fullname) > 1) {
								$lastname = array_pop($fullname);
								$firstname = implode(" ", $fullname);
							}
							else
							{
								$firstname = $row['CName'];
								$lastname = " ";
							}
							$dispName = $lastname. ", " .$firstname;
							echo "<option class='dropdown-item' value='".$row['ClientID']."'>".$dispName."</option> ";
						}			
echo "				</select>
				</div>
			</div>	  
	  
			<div class='form-group col-md-2'>
				<div class='dropdown'>
				<label for='ETypeDropdown'>Event Type*</label><br/>
					<!--<button class='btn btn-secondary dropdown-toggle' type='button' id='ETypeDropdown' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
					Select
					</button>-->
					<select name='type' class='browser-default custom-select' id='eventType' aria-labelledby='dropdownMenu2' required>
						<option class='dropdown-item' value=''>Select</option>		";
						
						$qry="SELECT EType, ETypeID FROM EType";
						$result = $db->query($qry);
						$num_rows = $result->num_rows;
						for ($i=0; $i<$num_rows; $i++)
						{
							$row = $result->fetch_assoc();
							echo "<option class='dropdown-item' value='".$row['ETypeID']."'>".$row['EType']."</option> ";
						}			
echo "				</select>
				</div>
			</div>
	  
			<div class='form-group col-md-5'>
				<label for='inputEName'>Event Name*</label>
				<input name='name' type='name' class='form-control' id='inputEName' placeholder='Event Name' required>
			</div>
			
			<div class='form-group col-md-2'>
			  <div class='dropdown'>
				<label for='VenueDropdown'>Venue*</label><br/>
					<select name='venue' class='browser-default custom-select' id='venue' aria-labelledby='dropdownMenu2' required>
						<option class='dropdown-itemVenue' value=''>Select</option>		";
						
						$qry="SELECT VName, VenueID FROM Venue";
						$result = $db->query($qry);
						$num_rows = $result->num_rows;
						for ($i=0; $i<$num_rows; $i++)
						{
							$row = $result->fetch_assoc();
							echo "<option class='dropdown-itemVenue' value='".$row['VenueID']."'>".$row['VName']."</option> ";
						}
echo "				</select>
				</div>
			</div>
		</div>
			
		<div class='form-row mb-2 mr-sm-1'>	
			<div class='form-group col-md-4'>
			<label for='StartTimePicker'>Start Date and Time*</label><br/>
				<input name='stime' id='input1' width='312' required/>
				<script>
					$('#input1').datetimepicker({ footer: true, modal: true });
				</script>
			</div>
			
			<div class='form-group col-md-4'>
			<label for='EndTimePicker'>End Date and Time*</label><br/>
				<input name='etime' id='input2' width='312' required/>
				<script>
					$('#input2').datetimepicker({ footer: true, modal: true });
				</script>
			</div>
			<button type='submit' name='CheckAvail' class='btn btn-info mb-4'>Check Date Availability</button>
		</form>
		
		
		</div>";
	  
	  
	  if (isset($_POST['CheckAvail']))
	  {
		$type = $_POST["type"];

		$name = $_POST["name"];
		$name = filter_var($name, FILTER_SANITIZE_STRING);
		
		$client = $_POST["client"];
		$clientid = (int) $client;
		$venue = $_POST["venue"];
		$venueid = (int) $venue;
		$prep = $db->prepare("SELECT VName FROM Venue WHERE VenueID=?");
		$prep->bind_param('i', $venueid); 
		$prep->execute();
		$res = $prep->get_result();
		$row = $res->fetch_assoc();
		$venueName = $row["VName"];		
		
		$stimeS = $_POST["stime"];
		$stimeObj = new DateTime($stimeS);
		$stime = $stimeObj->format('Y-n-j H:i:s');
		
		$etimeS = $_POST["etime"];
		$etimeObj = new DateTime($etimeS);
		$etime = $etimeObj->format('Y-n-j H:i:s');
		
		$duration = $stimeObj->diff($etimeObj);
		$duration = $duration->format('%d %h:%i:%s');
		$diffInSeconds = $etimeObj->getTimestamp() - $stimeObj->getTimestamp();
		
		$qry = "SELECT * FROM Venue,Events WHERE Venue.VenueID=Events.VenueID and Venue.VName='$venueName' and
				((Events.StartDate <= '$stime' and Events.EndDate >= '$etime') or
				(Events.StartDate > '$stime' and Events.EndDate < '$etime') or
				(Events.StartDate >= '$stime' and Events.EndDate > '$etime' and Events.StartDate < '$etime') or
				(Events.StartDate < '$stime' and Events.EndDate <= '$etime' and Events.EndDate > '$stime'))";
	  
	  
	$result = $db->query($qry);
	$resCount = $result->num_rows;
	
	if($resCount > 0)
	{
		//if results are returned then the date is taken
		
			
		for ($i=0; $i<$resCount; $i++)
		{
			$row = $result->fetch_assoc();
			$oldETimeS = $row["EndDate"];
		}
			
		$oldETimeObj = new DateTime($oldETimeS);
		$oldETime = $oldETimeObj->format('Y-n-j H:i:s');
		
		$newETimeObj = $oldETimeObj;
		$newETimeObj->add(new DateInterval('PT'.$diffInSeconds.'S'));
		$newETime = $newETimeObj->format('Y-n-j H:i:s');
		$duration = $oldETimeObj->diff($newETimeObj);
		$duration = $duration->format('%d %h:%i:%s');
		
		$qry = "SELECT * FROM Venue,Events WHERE Venue.VenueID=Events.VenueID and Venue.VName='$venueName' and
				((Events.StartDate <= '$oldETime' and Events.EndDate >= '$newETime') or
				(Events.StartDate > '$oldETime' and Events.EndDate < '$newETime') or
				(Events.StartDate >= '$oldETime' and Events.EndDate > '$newETime' and Events.StartDate < '$newETime') or
				(Events.StartDate < '$oldETime' and Events.EndDate <= '$newETime' and Events.EndDate > '$oldETime'))";
				
		$result = $db->query($qry);
		$resCount = $result->num_rows;
		
		if ($resCount > 0)
		{
			//if results are returned then the date is taken so search until one is free
			$loop = 1;
			while($loop == 1)
			{
				//make datetime obj from string, then save as string
				$startTimeObj = new DateTime($oldETime);
				$startTime = $startTimeObj->format('Y-n-j H:i:s');
				
				//make the endtime obj the start time plus interval, then save to string
				$endTimeObj = $startTimeObj;
				$endTimeObj->add(new DateInterval('PT'.$diffInSeconds.'S'));
				$endTime = $endTimeObj->format('Y-n-j H:i:s');
				$duration = $startTimeObj->diff($endTimeObj);
				$duration = $duration->format('%d %h:%i:%s');
				
				$qry = "SELECT * FROM Venue,Events WHERE Venue.VenueID=Events.VenueID and Venue.VName='$venueName' and
					((Events.StartDate <= '$startTime' and Events.EndDate >= '$endTime') or
					(Events.StartDate > '$startTime' and Events.EndDate < '$endTime') or
					(Events.StartDate >= '$startTime' and Events.EndDate > '$endTime' and Events.StartDate < '$endTime') or
					(Events.StartDate < '$startTime' and Events.EndDate <= '$endTime' and Events.EndDate > '$startTime'))";
				
				$result = $db->query($qry);
				$resCount = $result->num_rows;
				
				if ($resCount > 0)
				{
					//the date is still not free so do nothing
					$oldETime = $endTime;
				}
				else {
					//the date is free so send suggestion to user and set $loop to 0 to exit while loop
					echo "<script language='javascript'>
						alert('This event date and time conflicts with another. Instead try a Start Date and Time of $startTime and an End Date and Time of $endTime.')
						</script>";
					$loop = 0;
				}
			}
		}
		else
		{
			//the date is not taken, suggest new date to user
			echo "<script language='javascript'>
			alert('This event date and time conflicts with another. Instead try a Start Date and Time of $oldETime and an End Date and Time of $newETime.')
			</script>";
		}
		
	}
	else {
		//the date is not taken so proceed with form
		
		
		echo "		<form class='ml-3 mr-sm-2' action='Form Handlers/createScheduleHandler.php' method='post'>	
				
				
				</div>
				<div class='form-row mb-2 mr-sm-2'>
				
					<div class='form-group col-md-3'>
							<div class='dropdown'>
							<label for='PerformerDropdown'>Performer*</label><br/>
								<select name='performer' class='browser-default custom-select w-auto' id='performer' aria-labelledby='dropdownMenu2' required>
									<option class='dropdown-item' value=''>Select</option>		";
									
									$qry="SELECT PerformerID, PName FROM Performer";
									$result = $db->query($qry);
									$num_rows = $result->num_rows;
									for ($i=0; $i<$num_rows; $i++)
									{
										$row = $result->fetch_assoc();
										echo "<option class='dropdown-item' value='".$row['PerformerID']."'>".$row['PName']."</option> ";
									}
		echo "						</select>
							</div>
						</div>
						
						
						<div class='form-group col-md-2'>
							<label for='expAttendees'>Number of Expected Attendees</label>
							<input name='eattendees' type='number' class='form-control' id='expAttendees' placeholder='#'>
						</div>
						
						<div class='form-group col-md-2'>
							<label for='actAttendees'>Number of Actual Attendees*</label>
							<input name='aattendees' type='number' class='form-control' id='actAttendees' placeholder='#'>
						</div>
					
						<div class='form-group col-md-2'>
							<label for='inputCost'>Ticket Cost*</label>
							<input name='cost' type='number' class='form-control' id='inputCost' placeholder='Dollar Amount ($)' min='0.00' max='1000000.00' step='0.01' required>
						</div>
					
					</div>
				
				
				<div class='form-row mb-4 mr-sm-2'>
					<h6>&nbsp;Select the main Promotional Material used:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h6>";
					$qry="SELECT PromoMaterialID, MType FROM PromoMaterials";
									$result = $db->query($qry);
									$num_rows = $result->num_rows;
									for ($i=0; $i<$num_rows; $i++)
									{
										$row = $result->fetch_assoc();
										echo "<div class='custom-control custom-radio custom-control-inline'>";
										echo "<input type='radio' id='radio".($i+1)."' name='promo' value='".$row['PromoMaterialID']."' class='custom-control-input'>";
										echo "<label class='custom-control-label' value='".$row['PromoMaterialID']."' for='radio".($i+1)."'>".$row['MType']."</label>";
										echo "</div>";
									}
echo "					</div>
				
				
				<div class='form-row mb-2 mr-sm-2'>
				
					<div class='form-group col-md-6'>
						<label for='requirements'>Special Requirements</label>
						<textarea name='req' type='requirements' class='form-control' id='requirements' rows='3' placeholder='List any special requirements...'></textarea>
					</div>
					
					
				</div>
				
				<input type='hidden' name='client' id='hiddenField' value='$client' /> 
				<input type='hidden' name='type' id='hiddenField' value='$type' /> 
				<input type='hidden' name='name' id='hiddenField' value='$name' /> 
				<input type='hidden' name='venue' id='hiddenField' value='$venue' /> 
				<input type='hidden' name='stime' id='hiddenField' value='$stime' /> 
				<input type='hidden' name='etime' id='hiddenField' value='$etime' /> 
				<input type='hidden' name='duration' id='hiddenField' value='$duration' /> 
				
			  <button type='submit' name='CreateEvent' class='btn btn-info mb-4'>Create</button>
			  </form>		";		
				
				
				}//end of else
	  }
	  $db->close();
	  
	  ?>
	  
		
   </body>
</html>