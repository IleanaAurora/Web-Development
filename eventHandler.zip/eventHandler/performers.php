<?php
session_start();
include("dbConnection.php");
	if (isset($_SESSION['UserID']))
	{
		$currUserID = $_SESSION['UserID'];
	}
	else
	{
		echo "<script type='text/javascript'>
				window.location.href = './logout.php';
				</script>";
	}
?>

<!DOCTYPE html>
<html>
    <head>
 	<title>Performers</title>
	<?php include './Design/head.html'; 
		ini_set('display_errors', 1);
		ini_set('display_startup_errors', 1);
		error_reporting(E_ALL);
	?>
	<link href="CSS/main.css" rel="stylesheet">
	</head>
   <body>
		<?php include './Design/navBar.html';
		
		echo "	<div class='headings'>";
		
		$qry="SELECT * FROM Performer";
		$result = $db->query($qry);
		$num_rows = $result->num_rows;
		for ($i=0; $i<$num_rows; $i++)
		{
			$row = $result->fetch_assoc();
			echo "<form class='ml-3 mr-sm-2' action='editPage.php'>";
			echo "	<h1>".$row['PName']."</h1>";
			echo "  	<h2>".$row['PDescription']."</h2>";
			$img = str_replace(" ", '_', $row['PName']);
			$img = $img;
			$path="C:\\wamp64\\www\\eventHandler\\Images\\Performers\\".$img."\\2.jpg";
			if(file_exists($path))
			{			
				$img1 = $row['PImages']."1.jpg";
				$img2 = $row['PImages']."2.jpg";
				$img3 = $row['PImages']."3.jpg";
				$id = "photos".$i;
				
				echo "<div id='$id' class='carousel slide' data-ride='carousel'>";
				echo "	<ul class='carousel-indicators'>";
				echo "		<li data-target='#$id' data-slide-to='0' class='active'></li>";
				echo "		<li data-target='#$id' data-slide-to='1'></li>";
				echo "		<li data-target='#$id' data-slide-to='2'></li>";
				echo "	 </ul>";
			  
				echo "<div class='carousel-inner'>";
				echo "	<div class='carousel-item active'>";
				echo " 		<img src=$img1 class='img-fluid rounded mx-auto d-block'>";
				echo "	</div>";
				echo "	<div class='carousel-item'>";
				echo "  	<img src=$img2 class='img-fluid rounded mx-auto d-block'>";
				echo "	</div>";
				echo "	<div class='carousel-item'>";
				echo "  	<img src=$img3 class='img-fluid rounded mx-auto d-block'>";
				echo "	</div>";
				echo "</div>";
				echo "</div>";
			}
			elseif (!file_exists($path))
			{				
				$img = str_replace(" ", '_', $row['PImages']);
				$img = $img."1.jpg";
				echo "<img src=$img class='img-fluid rounded mx-auto d-block'>";
			}
		
		
		
			
			echo "			<h3>Contact: </h3>";
			echo "				<h4>".$row['PPhone']."  |  ".$row['PEmail']."</h4>";
			echo "			<h3>Fee: $".$row['Fees']."</h3>";
			echo "			<h3>Expected Audience Size: ".$row['ExpAudienceSize']."</h3>";
			echo "<button type='submit' name='EditPerformer' class='btn btn-light mb-4'><a href='editPage.php?editPerformerID=".$row['PerformerID']."'>Edit Performer</a></button>";
			echo "</form>";
			
		echo "</br>";
		echo "</br>";
		echo "</br>";
		echo "</br>";
		echo "</br>";
		}
		echo "	</div>";
		
		
		?>
		
	  
		
   </body>
</html>