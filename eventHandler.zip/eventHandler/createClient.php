<?php
session_start();
include("dbConnection.php");
if (isset($_SESSION['UserID']))
{
	$currUserID = $_SESSION['UserID'];
}
else
{
	echo "<script type='text/javascript'>
			window.location.href = './logout.php';
			</script>";
}
?>

<!DOCTYPE html>
<html>
    <head>
 	<title>Create Client</title>
	<?php include './Design/head.html'; ?>
	<link href='CSS/main.css' rel='stylesheet'>
	</head>
   <body>
		<?php include './Design/navBar.html';
		
		
		echo "	<br/>";
		echo "	<h5>&nbsp;&nbsp;&nbsp;Fill out the following fields to create a new client: </h5>";
		echo "	<h6><font color='red'>&nbsp;&nbsp;&nbsp;&nbsp;Please fill out all required fields marked with a *.</font></h6>";
		echo "	<br/>";
		
		
	echo "	<form class='ml-3 mr-sm-2' action='Form Handlers/createClientHandler.php' method='post'>
		<div class='form-row mb-2 mr-sm-2'>
	  
			<div class='form-group col-md-4'>
				<label for='inputCName'>Client Name*</label>
				<input name='CName' type='name' class='form-control' id='inputCName' placeholder='Client Name' required>
			</div>
			
			
			<div class='form-group col-md-2'>
				<label for='inputPhone'>Phone Number*</label>
				<input name='phone' type='tel' class='form-control' id='inputPhone' placeholder='xxx-xxx-xxxx' pattern='\d*' minlength='10' maxlength='11' required>
			</div>
			
			<div class='form-group col-md-3'>
				<label for='inputEmail'>Email*</label>
				<input name='email' type='email' class='form-control' id='inputEmail' placeholder='name@email.com' required>
			</div>
				
			
		</div>
	  <button type='submit' class='btn btn-info mb-4'>Create</button>
	  </form>";
		
		
		
		?>
		
	  
		
   </body>
</html>