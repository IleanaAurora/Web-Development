<?php
session_start();
include("dbConnection.php");
if (isset($_SESSION['UserID']))
{
	$currUserID = $_SESSION['UserID'];
}
else
{
	echo "<script type='text/javascript'>
			window.location.href = './logout.php';
			</script>";
}
?>

<!DOCTYPE html>
<html>
    <head>
 	<title>Create Venue</title>
	<?php include './Design/head.html'; ?>
	<link href="CSS/main.css" rel="stylesheet">
	</head>
   <body>
		<?php include './Design/navBar.html';
		
		
		echo "	<br/>";
		echo "	<h5>&nbsp;&nbsp;&nbsp;Fill out the following fields to create a new venue: </h5>";
		echo "	<h6><font color='red'>&nbsp;&nbsp;&nbsp;&nbsp;Please fill out all required fields marked with a *.</font></h6>";
		echo "	<br/>";
		
		
	echo "	<form enctype='multipart/form-data' class='ml-3 mr-sm-2' action='Form Handlers/createVenueHandler.php' method='post'>
	
		<div class='form-row mb-2 mr-sm-2'>
			<h6>General Information:</h6>			
		</div>
	
		<div class='form-row mb-2 mr-sm-2'>
	  
			<div class='form-group col-md-6'>
				<label for='inputVName'>Venue Name*</label>
				<input name='name' type='name' class='form-control' id='inputVName' placeholder='Name' required>
			</div>
			
			<div class='form-group col-md-2'>
				<label for='inputCost'>Rental Cost*</label>
				<input name='cost' type='number' class='form-control' id='inputCost' oninput='this.value = Math.abs(this.value)' placeholder='Dollar Amount ($)' min='0.00' max='1000000.00' step='0.01' required>
			</div>
			
			<div class='form-group col-md-2'>
				<label for='inputCapacity'>Capacity*</label>
				<input name='capacity' type='number' class='form-control' id='inputCapacity' oninput='this.value = Math.abs(this.value)' placeholder='Maximum # of people' min='0' step='1' required>
			</div>
			
		</div>
			
		<div class='form-row mb-2 mr-sm-2'>
		
			<div class='form-group col-md-6'>
				<label for='inputDescription'>Description</label>
				<textarea name='description' type='textarea' class='form-control' id='inputVDescription' rows='3' placeholder='Describe this venue...'></textarea>
			 </div>
			 
			 <div class='form-group col-md-6'>
				<label for='inputAvailEquipment'>Available Equipment and Amenities</label>
				<textarea name='equip' type='textarea' class='form-control' id='inputAvailEquipment' rows='3' placeholder='A/V equipment, stage, spotlights...'></textarea>
			 </div>
			
		</div>	
		
		<div class='form-row mb-2 mr-sm-2'>
			<h6>Contact Information:</h6>			
		</div>
		
		<div class='form-row mb-2 mr-sm-2'>
			<div class='form-group col-md-6'>
				<label for='inputAddress'>Address*</label>
				<input name='street' type='text' class='form-control' id='inputAddress' placeholder='1234 Main Street' required>
			</div>
		</div>
		
		<div class='form-row mb-2 mr-sm-2'>
		
			<div class='form-group col-md-6'>
				<label for='inputCity'>City*</label>
				<input name='city' type='text' class='form-control' id='inputCity' required>
			</div>
		
			<div class='form-group col-md-4'>
				<label for='inputState'>State*</label>
				<select name='state' id='inputState' class='form-control' required>
					<option value='AK'>Alaska</option>
					<option value='AL'>Alabama</option>
					<option value='AR'>Arkansas</option>
					<option value='AZ'>Arizona</option>
					<option value='CA'>California</option>
					<option value='CO'>Colorado</option>
					<option value='CT'>Connecticut</option>
					<option value='DC'>District of Columbia</option>
					<option value='DE'>Delaware</option>
					<option value='FL'>Florida</option>
					<option value='GA'>Georgia</option>
					<option value='HI'>Hawaii</option>
					<option value='IA'>Iowa</option>
					<option value='ID'>Idaho</option>
					<option value='IL'>Illinois</option>
					<option value='IN'>Indiana</option>
					<option value='KS'>Kansas</option>
					<option value='KY'>Kentucky</option>
					<option value='LA'>Louisiana</option>
					<option value='MA'>Massachusetts</option>
					<option value='MD'>Maryland</option>
					<option value='ME'>Maine</option>
					<option value='MI'>Michigan</option>
					<option value='MN'>Minnesota</option>
					<option value='MO'>Missouri</option>
					<option value='MS'>Mississippi</option>
					<option value='MT'>Montana</option>
					<option value='NC'>North Carolina</option>
					<option value='ND'>North Dakota</option>
					<option value='NE'>Nebraska</option>
					<option value='NH'>New Hampshire</option>
					<option value='NJ'>New Jersey</option>
					<option value='NM'>New Mexico</option>
					<option value='NV'>Nevada</option>
					<option selected='NY'>New York</option>
					<option value='OH'>Ohio</option>
					<option value='OK'>Oklahoma</option>
					<option value='OR'>Oregon</option>
					<option value='PA'>Pennsylvania</option>
					<option value='PR'>Puerto Rico</option>
					<option value='RI'>Rhode Island</option>
					<option value='SC'>South Carolina</option>
					<option value='SD'>South Dakota</option>
					<option value='TN'>Tennessee</option>
					<option value='TX'>Texas</option>
					<option value='UT'>Utah</option>
					<option value='VA'>Virginia</option>
					<option value='VT'>Vermont</option>
					<option value='WA'>Washington</option>
					<option value='WI'>Wisconsin</option>
					<option value='WV'>West Virginia</option>
					<option value='WY'>Wyoming</option>
				</select>
			</div>
		
			<div class='form-group col-md-2'>
				<label for='inputZip'>Zip*</label>
				<input name='zip' type='tel' class='form-control' id='inputZip' pattern='\d*' minlength='5' maxlength='5' required>
			</div>
			
		</div>
		
		<div class='form-row mb-2 mr-sm-2'>
		
			<div class='form-group col-md-2'>
				<label for='inputPhone'>Phone Number*</label>
				<input name='phone' type='tel' class='form-control' id='inputPhone' placeholder='xxx-xxx-xxxx' pattern='\d*' minlength='10' maxlength='11' required>
			</div>
			
			<div class='form-group col-md-2'>
				<label for='inputEmail'>Email*</label>
				<input name='email' type='email' class='form-control' id='inputEmail' placeholder='name@email.com' required>
			</div>
			
		</div>
		
		<div class='form-row mb-2 mr-sm-2'>
			<h6>Select an Image:</h6>			
		</div>
		
		<div class='form-row mb-4 mr-sm-2'>
		
			<div class='custom-file'>
				<input name='img' id='img' type='file' class='custom-file-input' accept='image/jpeg'>
				<label class='custom-file-label' for='validatedCustomFile'>Choose file...</label>
				<div class='invalid-feedback'>Invalid image file.</div>
			 </div>
		</div>
		
		
	  <button type='submit' id='uploadBtn' class='btn btn-info mb-4'>Create</button>
	  </form>";
		
		
		
		?>
		
	  
		
   </body>
</html>