window.onload = function() {
  document.getElementById('centimeters').style.display = 'none';
};

$(function () {
  $('[data-toggle="popover"]').popover()
})

function OnCM() { //hide ft & in bloc, show cm
  document.getElementById("feet").style.display = "none";
  document.getElementById("inches").style.display = "none";
  document.getElementById("centimeters").style.display = "block";
}

function OnFTIN() { //hide cm block, show others
  document.getElementById("feet").style.display = "block";
  document.getElementById("inches").style.display = "block";
  document.getElementById("centimeters").style.display = "none";
}

function calculateCals() {
  const activityLvls = [1.2,1.375,1.55,1.725,1.9];

  const gender = document.querySelector('input[name = "gender"]:checked').value;
  const rawWeight = document.getElementById("weight").value;
  const weightVal = document.querySelector('input[name = "weightVal"]:checked').value;
  let weight, height, bmr, maintenanceCals;
  if(weightVal === 'lb') {
    weight = rawWeight * 0.45359237;
  }
  else if (weightVal === 'st') {
    weight = rawWeight/0.15747;
  }
  else { weight = rawWeight; }
  const age = document.getElementById("age").value;
  const heightVal = document.querySelector('input[name = "height"]:checked').value;
  if(heightVal === 'ft') {
    const feet = document.getElementById("ft").value;
    const inches = document.getElementById("in").value;
    height = feet * 30.48 + inches * 2.54;
  }
  else if (heightVal === 'cm') {
    height = document.getElementById("cm").value;
  }
  const activityIndex = document.querySelector('input[name = "exerciseLvl"]:checked').value;
  const activityLvl = activityLvls[activityIndex];
  if(gender === 'male') {
    bmr = 10 * weight + 6.25 * height - 5 * age + 5;
  }
  else if (gender === 'female') {
    bmr = 10 * weight + 6.25 * height - 5 * age - 161;
  }
  maintenanceCals = Math.round(bmr * activityLvl);
  //alert(`You are a ${age} year old ${gender} who weighs ${weight} kg and is ${height} cm tall. Your exercise level is ${activityLvl}. Your maintenance cals are ${maintenanceCals}.`);
  document.getElementById("cals").textContent = `Your maintenance calories are ${maintenanceCals}.`;
}
